from pathlib import Path
import json,hashlib,shutil,xml.etree.ElementTree as ET
w=Path(__file__).resolve().parent;out=w.parent/'outputs'
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((w/'0127-full-inputs.json').read_text('utf-8'))
for n,h in inputs.items():assert digest(r/n)==h,n
assert 'BUILD SUCCESSFUL' in (w/'0127-full-second.log').read_text('utf-8')
results=list((r/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'))
summary=dict(tests=0,classes=len(results),failures=0,errors=0,skipped=0)
for p in results:
    root=ET.parse(p).getroot()
    for k in ('tests','failures','errors','skipped'):summary[k]+=int(root.attrib[k])
assert summary['tests']>=752 and summary['classes']>=124 and summary['failures']==summary['errors']==summary['skipped']==0,summary
lint=ET.parse(r/'app/build/reports/lint-results-debug.xml').getroot()
summary.update(lintErrors=sum(i.attrib['severity']=='Error' for i in lint),lintWarnings=sum(i.attrib['severity']=='Warning' for i in lint))
assert summary['lintErrors']==0
serviceInputs=json.loads((w/'0127-service-full-inputs.json').read_text('utf-8'))
for n,h in serviceInputs.items():assert digest(r/'team-service'/n)==h,n
cases={};failed=[]
for index in range(2):
    root=ET.parse(w/f'0127-service-full-{index}.xml').getroot()
    for case in root.iter('testcase'):
        key=(case.attrib['classname'],case.attrib['name']);assert key not in cases
        cases[key]=case
        if case.find('failure') is not None:failed.append(case)
assert len(cases)==248 and len(failed)==1 and 'ModuleNotFoundError' in ET.tostring(failed[0],encoding='unicode')
retest=list(ET.parse(w/'0127-service-fixture-retest.xml').getroot().iter('testcase'))
assert len(retest)==1 and retest[0].find('failure') is None and retest[0].find('error') is None
key=(retest[0].attrib['classname'],retest[0].attrib['name']);assert key==(failed[0].attrib['classname'],failed[0].attrib['name'])
cases[key]=retest[0]
assert all(all(c.find(k) is None for k in ('failure','error','skipped')) for c in cases.values())
service=dict(tests=len(cases),failures=0,errors=0,skipped=0,originalEnvironmentFailures=1,correctedFixtureRetests=1,
             note='All28 files covered; 247 passed initially; one missing desktop fixture import retested successfully after PYTHONPATH correction; original failures retained')
(w/'0127-service-full-summary.json').write_text(json.dumps(service,indent=2),encoding='utf-8')
old=json.loads((w/'0126-full-inputs.json').read_text('utf-8'))
for n,h in old.items():
    if n.startswith('app/schemas/'):assert inputs[n]==h,n
for n,h in json.loads((w/'desktop-full-second-inputs.json').read_text('utf-8')).items():assert digest(r/'desktop-organizer'/n)==h,n
metadata=json.loads((r/'app/build/outputs/apk/debug/output-metadata.json').read_text('utf-8'))['elements'][0]
assert metadata['versionCode']==39 and metadata['versionName']=='0.10.27'
cert='9f360690612dabcdc4c13c8fb0b89af99402a64782f8fdcba79cddfb2be745fa'
signature=(w/'0127-signature.txt').read_text('utf-8');assert 'Verifies' in signature and cert in signature
saved=w/'0127-full-second-results';saved.mkdir()
for p in results:shutil.copy2(p,saved/p.name)
shutil.copy2(r/'app/build/reports/lint-results-debug.xml',w/'0127-full-second-lint.xml')
(w/'0127-full-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
apk=out/'yuepuruanjian-0.10.27-stylus.apk';assert not apk.exists()
shutil.copy2(r/'app/build/outputs/apk/debug/app-debug.apk',apk)
shutil.copy2(r/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk',out/'yuepuruanjian-0.10.27-androidTest.apk')
report=dict(versionName='0.10.27',versionCode=39,size=apk.stat().st_size,sha256=digest(apk),**summary,
    sameSignature=True,certificateSha256=cert,appInputs=inputs,serviceInputs=serviceInputs,serviceFull=service,
    roomVersion=6,schemasUnchanged=True,databaseVersion=4,namingVersion=2,windowsSourcesUnchanged=True,
    serviceChange='annotations.py only; strict optional per-point pressures and protection against silent legacy stripping; no migration',
    related=dict(tests=61,classes=8,firstFailures=1,realFailure='Opposite contour winding cut holes at pressure joins; fixed and all61 passed'),
    nasPublished=False,productionApp='0.10.26 (38)',productionService='0.10.22',physicalAcceptance='pending user after publication',
    scope='Number15 standard stylus pressure and configured primary/secondary button temporary erase',
    limits=['Opt-in device preferences; only standard reported MotionEvent stylus pressure/button state; no proprietary double-tap simulation',
            'No physical pen latency/refresh/real hardware acceptance yet','Personal PDF area remains local basic reader without annotations'])
(out/'0.10.27-验证报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('APP_0127_SEALED',json.dumps({k:report[k] for k in ('size','sha256','tests','classes','lintErrors','lintWarnings','nasPublished')}),service)
