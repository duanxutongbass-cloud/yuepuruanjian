import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;
import java.time.Instant;
import java.util.*;

/** Bounded diagnostic attachment only after current user authorization.
 * Reads exception types and code locations, never values, messages, locals, or files.
 * Does not invoke target methods, install, click, authenticate, or submit deletion requests. */
public final class PadCleanupTrace {
  public static void main(String[] args) throws Exception {
    if(args.length!=1 || !args[0].matches("[0-9]{4,5}"))throw new IllegalArgumentException("Expected local forwarded port");
    var connector=Bootstrap.virtualMachineManager().attachingConnectors().stream()
        .filter(c->c.name().equals("com.sun.jdi.SocketAttach")).findFirst().orElseThrow();
    var options=connector.defaultArguments();
    options.get("hostname").setValue("127.0.0.1");options.get("port").setValue(args[0]);options.get("timeout").setValue("8000");
    VirtualMachine vm=connector.attach(options);ExceptionRequest request=null;
    try {
      request=vm.eventRequestManager().createExceptionRequest(null,true,true);
      request.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);request.enable();
      System.out.println("CLEANUP_TRACE_READY "+Instant.now());System.out.flush();
      long deadline=System.nanoTime()+60_000_000_000L;int recorded=0;boolean finished=false;
      while(!finished && recorded<200 && System.nanoTime()<deadline) {
        EventSet events=vm.eventQueue().remove(1000);if(events==null)continue;
        try {
          for(Event event:events) {
            if(!(event instanceof ExceptionEvent e))continue;
            var frames=e.thread().frames();
            if(frames.stream().noneMatch(f->f.location().declaringType().name().equals("com.ensemble.scorelibrary.sync.TeamDeletionCoordinator")))continue;
            var type=e.exception().referenceType().name();
            System.out.println("EXCEPTION "+Instant.now()+" "+type);recorded++;
            for(var frame:frames.stream().limit(45).toList()) {
              var loc=frame.location();System.out.println("  at "+loc.declaringType().name()+"."+loc.method().name()+":"+loc.lineNumber());
            }
            System.out.flush();
            if(type.equals("com.ensemble.scorelibrary.sync.TeamCleanupFailure"))finished=true;
          }
        } finally { events.resume(); }
      }
    } catch(VMDisconnectedException done) { System.out.println("CLEANUP_TRACE_DISCONNECTED"); }
    finally {
      try { if(request!=null)request.disable(); } catch(VMDisconnectedException ignored) {}
      try { vm.dispose(); } catch(VMDisconnectedException ignored) {}
    }
    System.out.println("CLEANUP_TRACE_ENDED "+Instant.now());
  }
}
