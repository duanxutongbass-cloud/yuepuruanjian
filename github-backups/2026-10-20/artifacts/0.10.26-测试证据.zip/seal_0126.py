from pathlib import Path
import json,hashlib,shutil,zipfile,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
out=root/'outputs';work=root/'work'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((work/'0126-full-inputs.json').read_text('utf-8'))
for name,value in inputs.items():assert digest(repo/name)==value,name
old=json.loads((work/'0125-full-inputs.json').read_text('utf-8'))
for name,value in old.items():
    if name.startswith('app/schemas/'):assert inputs[name]==value,name
for name,value in json.loads((work/'nas-0122/number13-release-inputs.json').read_text('utf-8'))['serviceInputs'].items():
    assert digest(repo/'team-service'/name)==value,name
for name,value in json.loads((work/'desktop-full-second-inputs.json').read_text('utf-8')).items():
    assert digest(repo/'desktop-organizer'/name)==value,name
log=(work/'0126-full-first.log').read_text('utf-8')
assert 'BUILD SUCCESSFUL' in log and 'FAILED' not in log
results=list((repo/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'))
summary=dict(tests=0,classes=len(results),failures=0,errors=0,skipped=0)
for p in results:
    x=ET.parse(p).getroot()
    for k in ('tests','failures','errors','skipped'):summary[k]+=int(x.attrib[k])
assert summary['tests']>=736 and summary['classes']>=122 and summary['failures']==summary['errors']==summary['skipped']==0,summary
lint=ET.parse(repo/'app/build/reports/lint-results-debug.xml').getroot()
summary.update(lintErrors=sum(i.attrib['severity']=='Error' for i in lint),lintWarnings=sum(i.attrib['severity']=='Warning' for i in lint))
assert summary['lintErrors']==0,summary
signature=(work/'0126-signature.txt').read_text('utf-8')
cert='9f360690612dabcdc4c13c8fb0b89af99402a64782f8fdcba79cddfb2be745fa'
assert 'Verifies' in signature and cert in signature
metadata=json.loads((repo/'app/build/outputs/apk/debug/output-metadata.json').read_text('utf-8'))['elements'][0]
assert metadata['versionCode']==38 and metadata['versionName']=='0.10.26'
saved=work/'0126-full-first-results';saved.mkdir()
for p in results:shutil.copy2(p,saved/p.name)
shutil.copy2(repo/'app/build/reports/lint-results-debug.xml',work/'0126-full-first-lint.xml')
(work/'0126-full-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
apk=out/'yuepuruanjian-0.10.26.apk';assert not apk.exists()
shutil.copy2(repo/'app/build/outputs/apk/debug/app-debug.apk',apk)
shutil.copy2(repo/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk',out/'yuepuruanjian-0.10.26-androidTest.apk')
report=dict(versionName='0.10.26',versionCode=38,size=apk.stat().st_size,sha256=digest(apk),**summary,
    sameSignature=True,certificateSha256=cert,appInputs=inputs,roomVersion=6,schemasUnchanged=True,
    serviceSourcesUnchanged=True,windowsSourcesUnchanged=True,nasPublished=False,productionApp='0.10.25 (37)',
    productionService='0.10.22; database 4; naming 2',relatedRuns=[dict(tests=20,classes=4),dict(tests=76,classes=14)],
    physicalAcceptance='pending user',nativePdfAcceptance='Android test APK compiled; native import/render/page acceptance NOT RUN',
    scope=['Personal/current-team library choice; unjoined personal access','Team and personal recycle multi-select confirmed purge; keep list/search',
           'Team management host survives library Loading/Error; closes on account change/logout','Existing number14 recent/favorite/page resume regression'],
    limits=['Personal PDFs local only; existing library/annotation backup excludes them; preserve external originals',
            'Personal basic PDF viewer has no annotations, performance or number14 reading/favorite integration',
            'Team limit 200 artifacts per preview; personal limit 100; no automatic split',
            'Multiple teams deferred to roadmap19; not implemented in this candidate'])
(out/'0.10.26-验证报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('APP_0126_SEALED',json.dumps({k:report[k] for k in ('versionName','versionCode','size','sha256','tests','classes','lintErrors','lintWarnings','nasPublished')}))
