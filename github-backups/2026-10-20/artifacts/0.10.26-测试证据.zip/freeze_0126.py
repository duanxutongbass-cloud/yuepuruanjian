from pathlib import Path
import hashlib,json
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
w=Path(__file__).resolve().parent
paths=[p for base in ('app/src','app/schemas') for p in (r/base).rglob('*') if p.is_file()]
paths += [r/n for n in ('app/build.gradle.kts','build.gradle.kts','settings.gradle.kts','gradle.properties','gradle/libs.versions.toml')]
values={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
old=json.loads((w/'0125-full-inputs.json').read_text('utf-8'))
assert all(n in values for n in old)
for n,h in old.items():
    if n.startswith('app/schemas/'):assert values[n]==h,n
(w/'0126-full-inputs.json').write_text(json.dumps(values,indent=2),encoding='utf-8')
print('APP_0126_INPUTS_FROZEN',len(values))
