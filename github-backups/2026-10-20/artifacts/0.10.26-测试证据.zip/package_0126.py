from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path(__file__).resolve().parent.parent
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
work=root/'work';out=root/'outputs'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tested=json.loads((work/'0126-full-inputs.json').read_text('utf-8'))
for name,value in tested.items():assert digest(repo/name)==value,name
names=set(json.loads((out/'0.10.25-源码校验.json').read_text('utf-8')))
names.update(tested);names.add('docs/LIBRARY_SPACES_0126.md')
manifest={n:dict(bytes=(repo/n).stat().st_size,sha256=digest(repo/n)) for n in sorted(names)}
archive=out/'0.10.26-完整源码.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(names):z.write(repo/name,'yuepuruanjian/'+name)
    z.writestr('SOURCE-SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,v in manifest.items():assert hashlib.sha256(z.read('yuepuruanjian/'+n)).hexdigest()==v['sha256'],n
(out/'0.10.26-源码校验.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(out/'0.10.26-测试证据.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(work.glob('0126-*.log')):z.write(p,p.name)
    for folder in ('0126-batch-first-results','0126-spaces-first-results','0126-full-first-results'):
        for p in sorted((work/folder).rglob('TEST-*.xml')):z.write(p,p.relative_to(work).as_posix())
    for n in ('0126-full-inputs.json','0126-full-summary.json','0126-full-first-lint.xml','0126-signature.txt','freeze_0126.py','seal_0126.py','package_0126.py'):
        z.write(work/n,n)
    for p in sorted((repo/'app/build/reports/screenshots').glob('0126-*.png')):
        z.write(p,'ui/'+p.name);shutil.copy2(p,out/p.name)
    for p in sorted((work/'0126-ui-proof').glob('*.png')):z.write(p,'ui/'+p.name)
    z.write(repo/'docs/LIBRARY_SPACES_0126.md','LIBRARY_SPACES_0126.md')
with zipfile.ZipFile(out/'0.10.26-测试证据.zip') as z:assert z.testzip() is None
print('APP_0126_SOURCE_AND_TESTS_PACKAGED',len(manifest),len(tested),archive.stat().st_size)
