"""APK-only account feedback update; existing multi-team runtime is preserved."""
from pathlib import Path
from contextlib import closing
import hashlib,json,os,sqlite3,urllib.request,urllib.error,uuid,zipfile,tempfile
from app_release import AppReleases

def fingerprint(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as source:
  while block:=source.read(65536):h.update(block);size+=len(block)
 return dict(size=size,sha256=h.hexdigest())

def publish(root,apk,expected,origin='https://124355.xyz:18443',allow_test_http=False):
 assert origin=='https://124355.xyz:18443' or allow_test_http and origin.startswith('http://127.0.0.1:')
 assert root.is_dir() and not root.is_symlink()
 import multiteam_storage as storage
 checked,marker=storage.checked_root(root)
 proof=json.loads((root/'deployment-0129.json').read_text('utf-8'))
 assert proof['destination']==str(checked.resolve()) and proof['primary']==marker['primary']
 assert proof['serviceInputs']==expected['serviceInputs'] and proof['independentSingleRestore'] and proof['independentMultiRestore']
 redirect=json.loads((Path(proof['source'])/'permanent-active.json').read_text('utf-8'))
 assert redirect['format']=='score-team-multi-redirect-v1' and redirect['directory']==str(checked.resolve())
 assert expected['versionCode']==43 and expected['versionName']=='0.10.31'
 assert fingerprint(apk)==dict(size=expected['size'],sha256=expected['sha256'])
 releases=AppReleases(root);before_path=root/'app-releases/before-0.10.31.json'
 current=releases.current()
 if before_path.exists():before=json.loads(before_path.read_text('utf-8'))
 else:
  assert current['versionCode']==42 and current['sha256']==expected['previousSha256']
  before=current
  with before_path.open('x',encoding='utf-8') as out:json.dump(before,out,ensure_ascii=False);out.flush();os.fsync(out.fileno())
 assert before['versionCode']==42 and before['sha256']==expected['previousSha256']
 assert fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
 assert current==before or current['versionCode']==43 and current['sha256']==expected['sha256']
 def get(path,binary=False):
  request=urllib.request.Request(origin+path,headers=({'If-Match':'"'+expected['sha256']+'"'} if binary else {}))
  class NoRedirect(urllib.request.HTTPRedirectHandler):
   def redirect_request(self,*args,**kwargs):return None
  try:response=urllib.request.build_opener(NoRedirect).open(request,timeout=30)
  except urllib.error.HTTPError as error:return error.code,None
  with response:
   assert response.url==origin+path,'Redirect refused'
   if not binary:return response.status,json.load(response)
   digest=hashlib.sha256();size=0
   while block:=response.read(65536):digest.update(block);size+=len(block)
   return response.status,dict(size=size,sha256=digest.hexdigest())
 status,public=get('/v1/app-release');assert status==200 and public['versionCode']==current['versionCode'] and public['sha256']==current['sha256']
 for route in ('/v1/catalog','/v2/catalog','/v1/admin/capabilities','/v2/admin/capabilities','/v1/me/teams','/v1/me/team-operations/'+str(uuid.uuid4())):
  assert get(route)[0]==401,'Private access unexpectedly allowed'
 value=releases.publish(apk,43,'0.10.31','修复注册校验、进度、错误和成功反馈；个人空间由本人管理，可创建自己的团队并加入其他团队，角色和乐谱授权分别管理。优化本机看谱：按需检查当前页段、复用已校验的私有文档，超时明确提示；曲库按既有编号自动显示01等分类文件夹。保留原签名、账号、曲谱、编号与设备，无需卸载。真机渲染速度由用户更新后验收。')
 status,public=get('/v1/app-release');assert status==200 and public['versionCode']==43 and public['sha256']==expected['sha256']
 status,download=get('/v1/app-release/apk',True);assert status==200 and download==dict(size=expected['size'],sha256=expected['sha256'])
 assert fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
 report=dict(release=value,previousReleaseRetained=True,fullPublicDownload=download,apkChannelOnly=True,multiTeamRoot=True,
  productionScoreOperations=False,physicalAcceptance='pending user',backup=str(before_path))
 proof=root/'app-releases/0.10.31-publication-proof.json'
 if proof.exists():assert json.loads(proof.read_text('utf-8'))==report
 else:
  with proof.open('x',encoding='utf-8') as out:json.dump(report,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())
 print('APP_0131_PUBLISHED_AND_FULL_DOWNLOAD_VERIFIED',json.dumps(report,ensure_ascii=False),flush=True)
 return report

def publish_bundle(root,bundle,expected,**options):
 assert fingerprint(bundle)==dict(size=expected['bundleSize'],sha256=expected['bundleSha256'])
 with zipfile.ZipFile(bundle) as z:
  rows=z.infolist();assert len(rows)==1 and rows[0].filename=='app.apk' and not rows[0].is_dir()
  assert rows[0].file_size==expected['size'] and rows[0].file_size<=256*1024*1024
  with tempfile.TemporaryDirectory(prefix='app-0131-') as directory:
   apk=Path(directory)/'app.apk'
   with z.open(rows[0]) as source,apk.open('xb') as target:
    count=0
    while block:=source.read(65536):
     count+=len(block);assert count<=expected['size'];target.write(block)
   assert count==expected['size']
   return publish(root,apk,expected,**options)

if __name__=='__main__':
 assert os.getuid()==10001
 folder=Path('/releases');expected=json.loads((folder/'0.10.31-inputs.json').read_text('utf-8'))
 publish_bundle(Path('/data/multiteam-0129'),folder/'app-0131-transfer.zip',expected)
