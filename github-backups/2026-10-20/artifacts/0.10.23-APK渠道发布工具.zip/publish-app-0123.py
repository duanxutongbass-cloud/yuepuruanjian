"""APK-channel update only. The running service and database are never migrated."""
from pathlib import Path
from contextlib import closing
import hashlib,json,os,sqlite3,urllib.request,urllib.error,uuid
from app_release import AppReleases

def fingerprint(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as source:
  while block:=source.read(65536):h.update(block);size+=len(block)
 return dict(size=size,sha256=h.hexdigest())

def publish(root,apk,expected,origin='https://124355.xyz:18443',allow_test_http=False):
 assert origin=='https://124355.xyz:18443' or allow_test_http and origin.startswith('http://127.0.0.1:')
 assert root.is_dir() and not root.is_symlink()
 marker=json.loads((root/'expanded-permanent-storage.json').read_text('utf-8'))
 active=json.loads((root/'permanent-active.json').read_text('utf-8'))
 with closing(sqlite3.connect((root/'team.sqlite3').as_uri()+'?mode=ro',uri=True)) as db:
  db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
  assert db.execute('PRAGMA user_version').fetchone()[0]==4
  metadata=dict(db.execute('SELECT key,value FROM metadata'))
  assert metadata['scoreNamingVersion']=='2' and metadata['numberingCandidateRoot']==str(root.resolve())
  assert metadata['numberingCandidateId']==marker['storageId']==active['storageId']
  assert active['teamId']==metadata['teamId'] and marker['format']=='score-team-expanded-permanent-storage-v1'
 assert expected['versionCode']==35 and expected['versionName']=='0.10.23'
 assert fingerprint(apk)==dict(size=expected['size'],sha256=expected['sha256'])
 releases=AppReleases(root);before_path=root/'app-releases/before-0.10.23.json'
 current=releases.current()
 if before_path.exists():before=json.loads(before_path.read_text('utf-8'))
 else:
  assert current['versionCode']==34 and current['sha256']==expected['previousSha256']
  before=current
  with before_path.open('x',encoding='utf-8') as out:json.dump(before,out,ensure_ascii=False);out.flush();os.fsync(out.fileno())
 assert before['versionCode']==34 and before['sha256']==expected['previousSha256']
 assert fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
 assert current==before or current['versionCode']==35 and current['sha256']==expected['sha256']
 def get(path,binary=False):
  request=urllib.request.Request(origin+path,headers=({'If-Match':'"'+expected['sha256']+'"'} if binary else {}))
  try:response=urllib.request.urlopen(request,timeout=30)
  except urllib.error.HTTPError as error:return error.code,None
  with response:
   assert response.url==origin+path,'Redirect refused'
   if not binary:return response.status,json.load(response)
   digest=hashlib.sha256();size=0
   while block:=response.read(65536):digest.update(block);size+=len(block)
   return response.status,dict(size=size,sha256=digest.hexdigest())
 status,public=get('/v1/app-release');assert status==200 and public['versionCode']==current['versionCode'] and public['sha256']==current['sha256']
 for route in ('/v1/catalog','/v2/catalog','/v1/admin/capabilities','/v2/admin/capabilities'):
  assert get(route)[0]==401,'Private access unexpectedly allowed'
 value=releases.publish(apk,35,'0.10.23','修复彻底删除后本机笔迹退休清理误判私有根路径，以及把本机清理失败误报成网络错误。保留登录和退休屏障，可重试加载；不会重复删除NAS曲谱。')
 status,public=get('/v1/app-release');assert status==200 and public['versionCode']==35 and public['sha256']==expected['sha256']
 status,download=get('/v1/app-release/apk',True);assert status==200 and download==dict(size=expected['size'],sha256=expected['sha256'])
 assert fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
 report=dict(release=value,previousReleaseRetained=True,fullPublicDownload=download,serviceChanged=False,databaseMigrated=False,
  productionScoreOperations=False,physicalAcceptance='pending user',backup=str(before_path))
 proof=root/'app-releases/0.10.23-publication-proof.json'
 if proof.exists():assert json.loads(proof.read_text('utf-8'))==report
 else:
  with proof.open('x',encoding='utf-8') as out:json.dump(report,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())
 print('APP_0123_PUBLISHED_AND_FULL_HTTPS_VERIFIED',json.dumps(report,ensure_ascii=False),flush=True)
 return report

if __name__=='__main__':
 assert os.getuid()==10001
 folder=Path('/releases');expected=json.loads((folder/'0.10.23-inputs.json').read_text('utf-8'))
 publish(Path('/data/expanded-0122'),folder/'yuepuruanjian-0.10.23-cleanup.apk',expected)
