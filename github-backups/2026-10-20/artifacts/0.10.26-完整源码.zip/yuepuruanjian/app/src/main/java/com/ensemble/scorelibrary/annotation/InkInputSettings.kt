package com.ensemble.scorelibrary.annotation

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Device input preference only: contains no account, PDF or ink data. */
@Singleton
class InkInputSettings @Inject constructor(@ApplicationContext context: Context) {
    private val preferences = context.getSharedPreferences("ink-input", Context.MODE_PRIVATE)
    fun load(): InkInputMode {
        val value = try { preferences.getString("mode", null) } catch (_: ClassCastException) { return InkInputMode.PEN }
        return if (value == null) InkInputMode.TOUCH else InkInputMode.entries.firstOrNull { it.name == value } ?: InkInputMode.PEN
    }
    fun save(mode: InkInputMode) { preferences.edit().putString("mode", mode.name).apply() }
}
