from pathlib import Path
import hashlib,http.client,json,os,time
from app_release import AppReleases
from backup_archive import fingerprint
from expanded_permanent import open_active

def verify_and_publish(data,releases,host='124355.xyz',port=18443,secure=True):
 root=data/'expanded-0122';source=data/'library';service=open_active(root)
 expected=json.loads((releases/'number13-release-inputs.json').read_text())
 proof_path=root/'number13-migration-complete.json';proof=json.loads(proof_path.read_text('utf-8'))
 assert proof['sourceBusinessUnchanged'] and proof['legacyIndependentRestore'] and proof['expandedIndependentRestore']
 assert proof['source']==str(source) and proof['destination']==str(root)
 saved=[p for p in (source/'backups').glob('number13-*/migration-proof.json') if p.read_bytes()==proof_path.read_bytes()]
 assert len(saved)==1,'Migration backup proof missing or ambiguous'
 for name,value in proof['backups'].items():assert fingerprint(saved[0].parent/name)==value,'Backup changed'
 for aid,value in proof['pdfs'].items():
  for directory in (source,root):assert fingerprint(directory/'artifacts'/(aid+'.pdf'))==value,'Original PDF changed'
 with service.connection() as db:
  assert db.execute('PRAGMA user_version').fetchone()[0]==4
 old=AppReleases(source).current();assert old==proof['previousRelease'] and old['versionCode']==33
 assert old['sha256']==expected['previousApkSha256']
 assert AppReleases(root).current()==old,'Unexpected channel; do not replay publication'
 old_apk=root/'app-releases'/(old['sha256']+'.apk');assert fingerprint(old_apk)==dict(size=old['size'],sha256=old['sha256'])
 def request(path,etag=None,binary=False):
  connection=(http.client.HTTPSConnection if secure else http.client.HTTPConnection)(host,port,timeout=20)
  try:
   connection.request('GET',path,headers={} if etag is None else {'If-Match':'"'+etag+'"'})
   reply=connection.getresponse();digest=hashlib.sha256();size=0;body=b''
   while block:=reply.read(65536):
    digest.update(block);size+=len(block)
    if not binary:
     assert size<65536;body+=block
   return reply.status,(dict(size=size,sha256=digest.hexdigest()) if binary else json.loads(body))
  finally:connection.close()
 for attempt in range(30):
  try:
   status,_=request('/v1/me')
   if status in (401,403):break
  except (OSError,http.client.HTTPException):pass
  time.sleep(1)
 else:raise AssertionError('Service health not verified; no APK publication')
 for path in ('/v1/catalog','/v2/catalog','/v1/admin/capabilities','/v2/admin/capabilities'):
  status,_=request(path);assert (status==401 if secure else status in (401,403)),'Anonymous private access was not rejected'
 status,current=request('/v1/app-release');assert status==200 and current['versionCode']==33 and current['sha256']==old['sha256']
 apk=releases/'yuepuruanjian-0.10.22-number13.apk'
 assert fingerprint(apk)==dict(size=expected['apkBytes'],sha256=expected['apkSha256'])
 metadata=AppReleases(root).publish(apk,expected['versionCode'],expected['versionName'],'编号13：扩位编号、全库最小空号及三端兼容。升级保留数据，真机功能待本人验收。')
 status,current=request('/v1/app-release');assert status==200 and current['versionCode']==34 and current['sha256']==metadata['sha256']
 status,download=request('/v1/app-release/apk',metadata['sha256'],True)
 assert status==200 and download==dict(size=metadata['size'],sha256=metadata['sha256'])
 assert AppReleases(source).current()==old and fingerprint(old_apk)==dict(size=old['size'],sha256=old['sha256'])
 report=dict(databaseVersion=4,namingVersion=2,localHealthVerified=True,anonymousPrivateRejected=True,previousApkRetained=True,
  backupProof=str(saved[0]),fullApkDownload=download,release=metadata,internalPublicationCompleted=True,
  publicDownloadVerified=secure,physicalAcceptance='pending user',productionScoresDeleted=False)
 with (root/'number13-publication-proof.json').open('x',encoding='utf-8') as out:
  json.dump(report,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())
 print('NUMBER13_SERVICE_HEALTH_AND_PUBLICATION_OK',json.dumps(report,ensure_ascii=False),flush=True)
 return report

if __name__=='__main__':
 assert os.getuid()==10001
 verify_and_publish(Path('/data'),Path('/releases'))
