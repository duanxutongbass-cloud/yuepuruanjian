from pathlib import Path
import hashlib,json,os,sys,zipfile,runpy,uuid
assert os.getuid()==10001
releases=Path('/releases')
bundle=releases/'number13-upgrade-tools.zip'
assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='0bf14a2a898690408bb778afa9995bcd851e0dfa826c17e7e9a54e5ad34797d0','Tool bundle changed'
expected=(releases/'number13-release-inputs.json').read_bytes()
assert hashlib.sha256(expected).hexdigest()=='567aa460ea9b45650ff57c621a027ddb8d34dfcef06179dd3813f0afb23a9e7e','Release inputs changed'
assert not Path('/data/expanded-0122').exists(),'Expanded target already exists; inspect retained proof'
target=Path('/data')/('number13-tools-'+uuid.uuid4().hex[:8]);target.mkdir(mode=0o700)
allowed=['service/security.py', 'service/service.py', 'service/catalog.py', 'service/publishing.py', 'service/backup_archive.py', 'service/app_release.py', 'service/annotations.py', 'service/programs.py', 'service/program_freezes.py', 'service/operation_records.py', 'service/personal_folders.py', 'service/score_numbers.py', 'service/number_inventory.py', 'service/expanded_candidate.py', 'service/expanded_protocol.py', 'service/expanded_permanent.py', 'service/permanent_storage.py', 'service/permanent_backup.py', 'service/permanent_deletion.py', 'service/permanent_journal.py', 'service/permanent_events.py', 'service/permanent_runtime.py', 'service/server.py', 'service/Dockerfile', 'service/requirements.txt', 'migrate.py', 'number13-release-inputs.json']
with zipfile.ZipFile(bundle) as z:
 assert len(z.namelist())==len(allowed) and set(z.namelist())==set(allowed) and z.testzip() is None
 assert z.read('number13-release-inputs.json')==expected
 for name in allowed:
  value=z.read(name)
  if name.endswith('.py'):compile(value,name,'exec')
  path=target/name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
  with path.open('xb') as out:out.write(value)
sys.path.insert(0,str(target/'service'))
runpy.run_path(str(target/'migrate.py'),run_name='__main__')
