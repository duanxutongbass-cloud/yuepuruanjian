"""Run only in a dedicated offline migration container after the writer is stopped.
No Docker access, SSH, credentials, production deletion or automatic rollback.
"""
from contextlib import closing
import hashlib,json,os,sqlite3,sys,traceback,uuid
from pathlib import Path

# sys.path is bound by a SHA-verified bootstrap to the shipped source directory.
from backup_archive import fingerprint
from permanent_storage import PermanentStorage
from permanent_backup import create_permanent_archive,restore_permanent_archive
from permanent_runtime import open_active as open_v1,activate as activate_v1,_rows
from expanded_permanent import prepare,activate,open_active,create_archive,restore_archive
from app_release import AppReleases


def hashes(root):
    with closing(sqlite3.connect((root/'team.sqlite3').as_uri()+'?mode=ro',uri=True)) as db:
        return {row[0]:{'size':row[2],'sha256':row[1]} for row in db.execute('SELECT id,hash,size FROM artifacts')}


def business(service):
    with service.connection() as db:
        result=_rows(db)
        # _rows intentionally omits the path-bound ledger; compare its business
        # contents explicitly, removing only the verified storage identity.
        result['artifact_tombstones']=[tuple(row) for row in db.execute('SELECT * FROM artifact_tombstones ORDER BY sequence')]
        jobs=[]
        for row in db.execute('SELECT owner,request,spec,plan,completed FROM permanent_deletion_jobs ORDER BY owner,request'):
            plan=json.loads(row['plan']);plan.pop('storageId')
            jobs.append((row['owner'],row['request'],row['spec'],json.dumps(plan,sort_keys=True),row['completed']))
        result['permanent_deletion_jobs']=jobs
        result['annotation_operation_targets']=[tuple(row) for row in db.execute('SELECT * FROM annotation_operation_targets ORDER BY account,request')]
        return result


def verify_pdfs(root,expected):
    actual={path.stem for path in (root/'artifacts').glob('*.pdf')}
    assert actual==set(expected),'Unexpected or missing managed PDFs'
    for aid,proof in expected.items():
        path=root/'artifacts'/(aid+'.pdf')
        assert path.stat().st_nlink==1 and fingerprint(path)==proof,'Changed or shared PDF'


def migrate(data,releases,source_modules):
    source=data/'library';destination=data/'expanded-0122'
    assert source.is_dir() and not destination.exists(),'Migration source/target mismatch'
    expected=json.loads((releases/'number13-release-inputs.json').read_text())
    for name,digest in expected['serviceInputs'].items():
        assert hashlib.sha256((source_modules/name).read_bytes()).hexdigest()==digest,'Service input changed'
    current=open_v1(source);release=AppReleases(source).current()
    assert release['versionCode']==33 and release['sha256']==expected['previousApkSha256'],'Expected current APK33, never rerun old releases'
    original=business(current);pdfs=hashes(source);verify_pdfs(source,pdfs)
    run='number13-'+__import__('datetime').datetime.now(__import__('datetime').timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
    backup=source/'backups'/run;backup.parent.mkdir(mode=0o700,exist_ok=True);backup.mkdir(mode=0o700)
    with closing(sqlite3.connect(current.path.as_uri()+'?mode=ro',uri=True)) as db,closing(sqlite3.connect(backup/'accounts-current.sqlite3')) as dest:db.backup(dest)
    legacy=backup/'current-v4-naming1.zip';create_permanent_archive(current,legacy)
    legacy_restore=backup/'independent-legacy';restore_permanent_archive(legacy,legacy_restore)
    activate_v1(legacy_restore,source,True)
    recovered=open_v1(legacy_restore)
    assert business(recovered)==original;verify_pdfs(legacy_restore,pdfs)
    assert business(current)==original,'Prior writer changed during backup; do not switch'
    prepare(legacy,destination);activate(destination,source,True)
    active=open_active(destination)
    assert business(active)==original;verify_pdfs(destination,pdfs)
    assert AppReleases(destination).current()==release,'Existing APK channel was not preserved'
    expanded=backup/'current-v4-naming2.zip';create_archive(active,expanded)
    restored=backup/'independent-expanded';restore_archive(expanded,restored);activate(restored,destination,True)
    assert business(open_active(restored))==original;verify_pdfs(restored,pdfs)
    assert business(current)==original;verify_pdfs(source,pdfs)
    proof=dict(format='number13-migration-proof',databaseVersion=4,namingVersion=2,source=str(source),destination=str(destination),
        sourceBusinessUnchanged=True,pdfs=pdfs,legacyIndependentRestore=True,expandedIndependentRestore=True,
        previousRelease=release,sourceInputs=expected['serviceInputs'],productionScoresDeleted=False,
        physicalAcceptance='pending user',publicationCompleted=False)
    proof['backups']={p.name:fingerprint(p) for p in (legacy,expanded,backup/'accounts-current.sqlite3')}
    raw=json.dumps(proof,ensure_ascii=False,indent=2)
    for path in (backup/'migration-proof.json',destination/'number13-migration-complete.json'):
        with path.open('x',encoding='utf-8') as out:out.write(raw);out.flush();os.fsync(out.fileno())
    print('NUMBER13_MIGRATION_AND_TWO_INDEPENDENT_RESTORES_OK',json.dumps({'proof':str(backup/'migration-proof.json'),'pdfCount':len(pdfs),'sourceUnchanged':True}),flush=True)


if __name__=='__main__':
    assert os.getuid()==10001,'Expected existing non-root service UID'
    migrate(Path('/data'),Path('/releases'),Path(__file__).parent/'service')
