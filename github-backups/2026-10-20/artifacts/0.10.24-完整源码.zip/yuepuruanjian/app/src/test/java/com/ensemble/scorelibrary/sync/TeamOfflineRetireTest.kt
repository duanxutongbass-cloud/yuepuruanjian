package com.ensemble.scorelibrary.sync

import com.ensemble.scorelibrary.account.*
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.UUID
import javax.crypto.spec.SecretKeySpec

@RunWith(RobolectricTestRunner::class)
class TeamOfflineRetireTest {
    @get:Rule val temporary=TemporaryFolder()
    private val key=SecretKeySpec(ByteArray(32) { 4 },"AES")
    private val now=System.currentTimeMillis()/1000
    private val s=TeamSession(TEAM_SERVICE_URL,"s".repeat(43),now+3600,TeamPrincipal(
        UUID.randomUUID().toString(),UUID.randomUUID().toString(),UUID.randomUUID().toString(),
        "Team","player","Player","member",true),now,now,UUID.randomUUID().toString())
    private fun store()=TeamOfflineStore(temporary.root,{key},{now})
    private fun a(n:String)=TeamArtifact(UUID.randomUUID().toString(),"Score","Violin","a".repeat(64),100,1,n,"")
    @Test fun lateSave() {
        val gone=a("0101001");val keep=a("0101002")
        val ordinary=TeamProgram(UUID.randomUUID().toString(),"Programme",listOf(gone.pieceKey,keep.pieceKey))
        val frozen=TeamProgram(UUID.randomUUID().toString(),"Frozen",listOf(gone.pieceKey),UUID.randomUUID().toString(),listOf(gone.id))
        val c=TeamCatalog(1,listOf(gone,keep),listOf(ordinary,frozen))
        store().save(s,c);store().retire(s,setOf(gone.id)) {}
        store().save(s,c)
        val result=store().read(s.copy(offline=true)).catalog
        assertEquals(listOf(keep),result.artifacts)
        assertEquals(listOf(ordinary.copy(pieceKeys=listOf(keep.pieceKey))),result.programs)
        store().invalidate(s);store().save(s,c)
        assertEquals(listOf(keep),store().read(s).catalog.artifacts)
    }
    @Test fun isolationAndDenial() {
        val a=a("0101001");val c=TeamCatalog(1,listOf(a))
        val other=s.copy(principal=s.principal.copy(accountId=UUID.randomUUID().toString()))
        store().save(s,c);store().save(other,c)
        assertThrows(IllegalStateException::class.java) { store().retire(s,setOf(a.id)) { error("changed") } }
        assertEquals(c,store().read(s).catalog)
        store().retire(s,setOf(a.id)) {}
        assertTrue(store().read(s).catalog.artifacts.isEmpty())
        assertEquals(c,store().read(other).catalog)
    }
}
