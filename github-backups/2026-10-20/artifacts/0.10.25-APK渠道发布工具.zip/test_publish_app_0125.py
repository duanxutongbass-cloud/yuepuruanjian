from pathlib import Path
import sys,importlib.util,json,zipfile,threading
root=Path('C:/Users/dxt/Documents/Codex/2026-10-18/yuepu-number13')
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service');sys.path.insert(0,str(repo))
from expanded_permanent import ExpandedReadyApplication,open_active
from app_release import AppReleases
from waitress import create_server
spec=importlib.util.spec_from_file_location('publish0125',root/'work/publish_app_0125.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
data=root/'work/nas-migration-test-fifth/data/expanded-0122'
old=AppReleases(data).current();assert old['versionCode']==36
apk=root/'work/synthetic-0125-not-installable.apk'
with zipfile.ZipFile(apk,'x') as z:z.writestr('AndroidManifest.xml',b'Synthetic37');z.writestr('classes.dex',b'Isolated fixture37')
expected=dict(m.fingerprint(apk),versionCode=37,versionName='0.10.25',previousSha256=old['sha256'])
bundle=root/'work/synthetic-0125-transfer.zip'
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:z.write(apk,'app.apk')
expected.update(bundleSize=bundle.stat().st_size,bundleSha256=m.fingerprint(bundle)['sha256'])
server=create_server(ExpandedReadyApplication(open_active(data),allow_loopback_http=True),host='127.0.0.1',port=0,threads=2)
worker=threading.Thread(target=server.run,daemon=True);worker.start()
try:
 result=m.publish_bundle(data,bundle,expected,origin=f'http://127.0.0.1:{server.effective_port}',allow_test_http=True)
 assert result['previousReleaseRetained'] and not result['serviceChanged'] and not result['databaseMigrated']
 assert m.publish_bundle(data,bundle,expected,origin=f'http://127.0.0.1:{server.effective_port}',allow_test_http=True)==result
 # Bad transfer integrity must not change an already published channel.
 bad=dict(expected,bundleSha256='0'*64)
 try:m.publish_bundle(data,bundle,bad);raise AssertionError('Tampered transfer accepted')
 except AssertionError as e:
  if str(e)=='Tampered transfer accepted':raise
 assert AppReleases(data).current()==result['release']
 print('SYNTHETIC_APP_ONLY_BUNDLE_PUBLICATION_RETRY_AND_TAMPER_REJECTION_VERIFIED')
finally:server.task_dispatcher.shutdown();server.close();worker.join(5)
