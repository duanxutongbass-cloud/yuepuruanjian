from __future__ import annotations

import uuid
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSplitter,
    QTableWidgetItem, QVBoxLayout, QWidget)

from score_organizer.services.team_publish import TeamClient
from score_organizer.services.runtime_services import publish as PublishService
from score_organizer.domain.score_naming import format_score_number
from score_organizer.ui.readable_table import ReadableTableWidget


class PublishWorker(QThread):
    succeeded = Signal(object)
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, callback, parent):
        super().__init__(parent)
        self.callback = callback

    def run(self):
        try:
            self.succeeded.emit(self.callback(self.progress.emit))
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.callback = None


class TeamPublishDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.setWindowTitle('上传乐谱到管理员总库')
        self.resize(1120, 780)
        self.db, self.service = db, PublishService(db)
        self.client = self.worker = self.plan = None
        self.assignments, self.member_names = {}, {}
        self.publisher_id = db.get_setting('team_publisher_id', '') or str(uuid.uuid4())
        db.set_setting('team_publisher_id', self.publisher_id)
        layout = QVBoxLayout(self)
        self.controls = QWidget()
        content = QVBoxLayout(self.controls)
        form = QFormLayout()
        self.address = QLineEdit(db.get_setting('team_server_address', ''))
        self.address.setPlaceholderText('https://你的乐谱服务域名')
        self.username, self.password = QLineEdit(), QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.login_button = QPushButton('管理员登录 / 刷新成员')
        form.addRow('服务地址', self.address)
        row = QHBoxLayout()
        row.addWidget(QLabel('账号'))
        row.addWidget(self.username)
        row.addWidget(QLabel('密码'))
        row.addWidget(self.password)
        row.addWidget(self.login_button)
        form.addRow(row)
        content.addLayout(form)
        content.addWidget(QLabel('选择独立 PDF，先上传管理员总库，再由管理员分发。不限总份数，自动分批上传。'))
        self.library_only = QCheckBox('仅上传管理员总库，稍后再分发给成员')
        self.library_only.setChecked(True)
        content.addWidget(self.library_only)
        self.search = QLineEdit()
        self.search.setPlaceholderText('按编号、曲名、分类或乐器搜索；筛选会清除当前行选择')
        content.addWidget(self.search)
        split = QSplitter(Qt.Horizontal)
        self.scores = ReadableTableWidget(0, 5)
        self.scores.setHorizontalHeaderLabels(['编号', '曲名', '分类', '乐器', '接收成员'])
        self.scores.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.scores.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.scores.setEditTriggers(QAbstractItemView.NoEditTriggers)
        split.addWidget(self.scores)
        member_panel = QWidget()
        member_layout = QVBoxLayout(member_panel)
        member_layout.addWidget(QLabel('勾选接收成员（不会自动全选）'))
        self.members = QListWidget()
        self.members.setEnabled(False)
        member_layout.addWidget(self.members)
        self.assign_button = QPushButton('添加所选分谱到上传清单')
        self.remove_button = QPushButton('取消所选分谱发布')
        member_layout.addWidget(self.assign_button)
        member_layout.addWidget(self.remove_button)
        split.addWidget(member_panel)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 1)
        content.addWidget(split, 1)
        self.preview_button = QPushButton('生成上传预览')
        content.addWidget(self.preview_button)
        self.preview = ReadableTableWidget(0, 6)
        self.preview.setHorizontalHeaderLabels(['编号 / 曲名', '分类', '乐器', '大小', 'SHA-256', '接收成员'])
        self.preview.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.preview.setMaximumHeight(180)
        content.addWidget(self.preview)
        self.confirm = QCheckBox('我已逐份核对独立 PDF、编号、分类及声部；入总库不会分发给普通成员')
        content.addWidget(self.confirm)
        self.publish_button = QPushButton('确认上传管理员总库')
        self.publish_button.setEnabled(False)
        content.addWidget(self.publish_button)
        layout.addWidget(self.controls, 1)
        self.status = QLabel('请先连接团队服务。密码和登录凭据仅保存在本次窗口内存中。')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.login_button.clicked.connect(self.login)
        self.search.textChanged.connect(self.filter_scores)
        self.assign_button.clicked.connect(self.assign)
        self.remove_button.clicked.connect(self.remove)
        self.preview_button.clicked.connect(self.make_preview)
        self.library_only.toggled.connect(self.mode_changed)
        self.confirm.toggled.connect(lambda checked:self.publish_button.setEnabled(bool(checked and self.plan and self.client)))
        self.publish_button.clicked.connect(self.publish)
        categories = {r['code']:r['name'] for r in db.list_categories()}
        self.rows = list(db.list_archived_scores())
        self.scores.setRowCount(len(self.rows))
        for row, score in enumerate(self.rows):
            values = [format_score_number(score["instrument_code"],score["category_code"],score["seq"],naming_version=self.db._numbering_version), score['display_title'],
                      f"{score['category_code']} {categories[score['category_code']]}", f"{score['instrument_code']} {score['instrument_name']}", '未分配']
            for column, value in enumerate(values):
                self.scores.setItem(row, column, QTableWidgetItem(value))
        self.scores.fit_default_columns({0:95, 2:125, 3:150})

    def invalidate(self):
        self.plan = None
        self.confirm.setChecked(False)
        self.publish_button.setEnabled(False)
        self.preview.setRowCount(0)

    def mode_changed(self, library_only):
        self.invalidate()
        self.assignments.clear()
        self.members.setEnabled(not library_only)
        self.assign_button.setText('添加所选分谱到上传清单' if library_only else '分配接收成员 → 所选分谱')
        self.publish_button.setText('确认上传管理员总库' if library_only else '确认上传并分发')
        self.confirm.setText('我已逐份核对独立 PDF、编号、分类及声部；入总库不会分发给普通成员' if library_only
                             else '我已逐份核对独立 PDF 和预览中的接收成员')
        self.refresh_assignments()

    def run(self, callback, success):
        if self.worker and self.worker.isRunning():
            return
        self.controls.setEnabled(False)
        self.worker = PublishWorker(callback, self)
        self.worker.progress.connect(self.status.setText)
        self.worker.succeeded.connect(success)
        self.worker.failed.connect(self.failed)
        self.worker.finished.connect(lambda:self.controls.setEnabled(True))
        self.worker.start()

    def failed(self, message):
        self.status.setText(message + '。若上传中断，可重试相同发布；以服务器发布回执为准。')
        if self.client and not self.client.token:
            self.invalidate()

    def login(self):
        self.invalidate()
        self.assignments.clear()
        self.members.clear()
        try:
            client = TeamClient(self.address.text(), self.publisher_id)
        except ValueError as exc:
            self.status.setText(str(exc))
            return
        username, password, previous = self.username.text(), self.password.text(), self.client
        self.password.clear()
        self.client = None
        self.refresh_assignments()
        def connect(progress):
            progress('正在登录并读取团队成员…')
            if previous:
                try:
                    previous.logout()
                except ValueError:
                    pass
            try:
                client.login(username, password)
                return client, client.request('GET', '/v1/admin/members')['members']
            except Exception:
                try:
                    client.logout()
                except ValueError:
                    pass
                raise
        self.run(connect, self.connected)

    def connected(self, result):
        self.client, members = result
        self.address.setText(self.client.address)
        self.db.set_setting('team_server_address', self.client.address)
        self.member_names = {}
        for member in members:
            if not member['active']:
                continue
            name = f"{member['displayName']}（{member['username']}）"
            self.member_names[member['accountId']] = name
            item = QListWidgetItem(name)
            item.setData(Qt.UserRole, member['accountId'])
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.members.addItem(item)
        self.status.setText(f"已连接 {self.client.principal['teamName']} · {self.client.address}；选择分谱后可直接生成上传预览。")

    def filter_scores(self, value):
        self.scores.clearSelection()
        for row in range(self.scores.rowCount()):
            self.scores.setRowHidden(row, value.casefold() not in ' '.join(self.scores.item(row,c).text() for c in range(4)).casefold())

    def selected(self):
        return sorted({index.row() for index in self.scores.selectionModel().selectedRows() if not self.scores.isRowHidden(index.row())})

    def assign(self):
        recipients = ((self.client.principal['accountId'],) if self.library_only.isChecked() and self.client else
                      tuple(self.members.item(i).data(Qt.UserRole) for i in range(self.members.count()) if self.members.item(i).checkState() == Qt.Checked))
        rows = self.selected()
        if not self.client or not rows or not recipients:
            self.status.setText('请先登录并选择分谱。' if self.library_only.isChecked() else '请先登录，并同时选择分谱和接收成员。')
            return
        self.invalidate()
        for row in rows:
            self.assignments[int(self.rows[row]['id'])] = recipients
        self.refresh_assignments()

    def remove(self):
        self.invalidate()
        for row in self.selected():
            self.assignments.pop(int(self.rows[row]['id']), None)
        self.refresh_assignments()

    def refresh_assignments(self):
        for row, score in enumerate(self.rows):
            text = ('管理员总库（稍后分发）' if self.library_only.isChecked() and int(score['id']) in self.assignments else
                    '、'.join(self.member_names.get(a, a) for a in self.assignments.get(int(score['id']), ())) or '未选择')
            self.scores.item(row, 4).setText(text)

    def make_preview(self):
        self.invalidate()
        if not self.client:
            self.status.setText('请先以团队管理员账号登录。')
            return
        if self.library_only.isChecked() and self.selected():
            self.assign()
        assignments = dict(self.assignments)
        self.run(lambda progress:self.service.build_plan(assignments), self.show_preview)

    def show_preview(self, plan):
        self.plan = plan
        self.preview.setRowCount(len(plan.parts))
        for row, part in enumerate(plan.parts):
            values = [f'{part.number} {part.title}', part.category, part.part_name, f'{part.size/1024:.1f} KiB',
                      part.digest[:12] + '…', '管理员总库（稍后分发）' if self.library_only.isChecked() else '、'.join(self.member_names.get(a, a) for a in part.accounts)]
            for column, value in enumerate(values):
                self.preview.setItem(row, column, QTableWidgetItem(value))
            self.preview.item(row, 4).setToolTip(part.digest)
        self.preview.fit_default_columns({1:125, 2:150, 3:85, 4:130})
        self.status.setText(f'已校验 {len(plan.parts)} 份分谱及全部库内副本。请核对上方预览，再勾选确认。')

    def publish(self):
        if not self.plan or not self.client or not self.confirm.isChecked():
            return
        if self.address.text().strip().rstrip('/') != self.client.address:
            self.status.setText('服务地址已修改，请重新登录。')
            return
        action = '上传到管理员总库，仅上传管理员可阅读，之后另行分发' if self.library_only.isChecked() else '上传并授权预览中的接收成员'
        if QMessageBox.question(self, '确认上传', f'向 {self.client.address} {action} {len(self.plan.parts)} 份？将自动分批。',
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        plan, client = self.plan, self.client
        self.run(lambda progress:self.service.publish(plan, client, self.publisher_id, confirmed=True, progress=progress), self.published)

    def published(self, receipt):
        batches = len(receipt.get('publicationIds', [receipt['publicationId']]))
        self.status.setText(f"上传成功：{len(receipt['artifactIds'])} 份，{batches} 批。最后回执：{receipt['publicationId']}。本地原文件和编号保持不变。")
        self.invalidate()

    def reject(self):
        if self.worker and self.worker.isRunning():
            self.status.setText('正在执行操作，请等待完成后关闭。')
            return
        if self.client:
            client, self.client = self.client, None
            self.run(lambda progress:client.logout(), lambda _:super(TeamPublishDialog, self).reject())
            self.worker.failed.disconnect(self.failed)
            self.worker.failed.connect(lambda _:super(TeamPublishDialog, self).reject())
            return
        super().reject()

    def closeEvent(self, event):
        event.ignore()
        self.reject()
