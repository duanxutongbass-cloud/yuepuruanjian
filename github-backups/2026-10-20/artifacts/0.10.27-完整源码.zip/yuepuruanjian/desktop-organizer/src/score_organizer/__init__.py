"""Score organizer package."""

