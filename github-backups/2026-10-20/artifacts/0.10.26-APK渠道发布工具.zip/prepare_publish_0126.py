from pathlib import Path
import json,re,hashlib,zipfile
w=Path(__file__).resolve().parent;r=w.parent;out=r/'outputs';stage=w/'0126-nas'
stage.mkdir()
report=json.loads((out/'0.10.26-验证报告.json').read_text('utf-8'))
assert report['tests']==736 and report['failures']==report['errors']==report['skipped']==0
apk=out/'yuepuruanjian-0.10.26.apk'
assert apk.stat().st_size==report['size'] and hashlib.sha256(apk.read_bytes()).hexdigest()==report['sha256']
old=json.loads((out/'0.10.25-完成验证.json').read_text('utf-8'))
previous='2de632a9ae65047fb7341ebf5bf2549338078ca2d6c2a8dc6f40bf0f8c2181d3'
def adapt(text):
    text=text.replace('0.10.25','0.10.26').replace('0125','0126')
    return re.sub(r'\b(36|37)\b',lambda m:{'36':'37','37':'38'}[m[0]],text)
source=adapt((w/'publish_app_0125.py').read_text('utf-8'))
notes='曲库直接选择个人（仅本机）与当前团队名称；未入团可使用个人文件。团队管理员及本人个人回收站支持多选、合并预览勾选确认彻底删除，删除后保留回收站和搜索。保留最近阅读、收藏、页码恢复及25清理修复。多团队按19号后续开发；个人文件不随团队同步，现有备份不含。'
start=source.index("'修复编号协议升级后，");end=source.index("')",start)
source=source[:start]+repr(notes)+source[end+1:]
compile(source,'publish_app_0126.py','exec')
(w/'publish_app_0126.py').write_text(source,encoding='utf-8',newline='\n')
(stage/'publish-app-0126.py').write_bytes(source.encode('utf-8'))
test=adapt((w/'test_publish_app_0125.py').read_text('utf-8')).replace('Synthetic37','Synthetic38').replace('fixture37','fixture38')
compile(test,'test_publish_app_0126.py','exec');(w/'test_publish_app_0126.py').write_text(test,encoding='utf-8',newline='\n')
verify=adapt((w/'verify_public_0125_direct.py').read_text('utf-8'))
(w/'verify_public_0126_direct.py').write_text(verify,encoding='utf-8',newline='\n')
bundle=stage/'app-0126-transfer.zip'
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:z.write(apk,'app.apk')
expected=dict(versionCode=38,versionName='0.10.26',size=report['size'],sha256=report['sha256'],previousSha256=previous,
              bundleSize=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest())
config=json.dumps(expected,indent=2).encode('utf-8');(stage/'0.10.26-inputs.json').write_bytes(config)
command=f"import hashlib,pathlib; p=pathlib.Path('/releases/publish-app-0126.py'); raw=p.read_bytes(); assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256(source.encode('utf-8')).hexdigest()!r}; assert hashlib.sha256(pathlib.Path('/releases/0.10.26-inputs.json').read_bytes()).hexdigest()=={hashlib.sha256(config).hexdigest()!r}; exec(compile(raw,str(p),'exec'),{{'__name__':'__main__','__file__':str(p)}})"
compose='''services:
  publish:
    image: yuepu-team-api:0.10.22
    entrypoint: ["python", "-c"]
    command:
      - '''+json.dumps(command)+'''
    user: "10001:10001"
    volumes:
      - team-data-0119:/data
      - /volume1/docker/yuepuruanjian-team-service/team-service/releases:/releases:ro
    read_only: true
    tmpfs:
      - /tmp:size=128m,mode=1777
    cap_drop: [ALL]
    security_opt: [no-new-privileges:true]
    mem_limit: 256m
    restart: "no"
volumes:
  team-data-0119:
    external: true
    name: yuepu-team-api_team-data-0119
networks:
  default:
    external: true
    name: yuepu-team-api_default
'''
(stage/'compose-app-0126.yaml').write_bytes(compose.encode('utf-8'))
print('APP_0126_PUBLICATION_PREPARED',expected['bundleSize'],hashlib.sha256(source.encode('utf-8')).hexdigest())
