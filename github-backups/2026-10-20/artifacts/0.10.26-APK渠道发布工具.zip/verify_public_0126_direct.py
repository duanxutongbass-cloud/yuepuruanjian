from pathlib import Path
import http.client,json,hashlib,datetime
r=Path('C:/Users/dxt/Documents/Codex/2026-10-18/yuepu-number13');e=json.loads((r/'work/0126-nas/0.10.26-inputs.json').read_text('utf-8'))
def get(path,download=None):
 c=http.client.HTTPSConnection('124355.xyz',18443,timeout=30)
 try:
  c.request('GET',path,headers=({'If-Match':'"'+e['sha256']+'"'} if download else {}));p=c.getresponse()
  if download:
   h=hashlib.sha256();size=0
   with download.open('xb') as out:
    while b:=p.read(65536):out.write(b);h.update(b);size+=len(b)
   return p.status,dict(size=size,sha256=h.hexdigest())
  return p.status,json.loads(p.read())
 finally:c.close()
status,m=get('/v1/app-release');assert status==200 and m['versionCode']==38 and m['sha256']==e['sha256']
path=r/'work/nas-public-0.10.26-direct.apk';status,d=get('/v1/app-release/apk',path)
assert status==200 and d==dict(size=e['size'],sha256=e['sha256'])
routes=json.loads((r/'outputs/nas-0.10.22-public-verification.json').read_text('utf-8'))['anonymousPrivate'];checks={}
for route in routes:
 status,_=get(route);assert status==401,(route,status);checks[route]=status
report=dict(verifiedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),metadata=m,fullDownload=d,anonymousPrivate=checks,
 tlsVerification=True,transport='Direct HTTPS with default certificate verification; system proxy configuration unchanged',
 serviceChanged=False,databaseMigrated=False,productionScoreOperations=False,physicalAcceptance='pending user')
(r/'outputs/nas-0.10.26-public-verification.json').write_bytes(json.dumps(report,ensure_ascii=False,indent=2).encode('utf-8'))
print('APP_0126_DIRECT_FULL_PUBLIC_APK_AND_20_PRIVATE_ROUTES_OK',d)
