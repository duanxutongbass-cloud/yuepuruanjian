from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
r=Path(__file__).resolve().parent.parent;w=r/'work';out=r/'outputs'
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((w/'0126-nas/0.10.26-inputs.json').read_text('utf-8'))
line=next(l.strip() for l in (w/'0126-nas-deployment-dom.txt').read_text('utf-8').splitlines()
          if l.strip().startswith('- generic: "APP_0126_PUBLISHED_AND_FULL_HTTPS_VERIFIED '))
message=json.loads(line.removeprefix('- generic: '));proof=json.loads(message.split(' ',1)[1])
public=json.loads((out/'nas-0.10.26-public-verification.json').read_text('utf-8'))
assert dict(proof['release'],available=True)==public['metadata']
assert proof['previousReleaseRetained'] and proof['fullPublicDownload']==public['fullDownload']==dict(size=expected['size'],sha256=expected['sha256'])
assert len(public['anonymousPrivate'])==20 and all(v==401 for v in public['anonymousPrivate'].values())
assert not proof['serviceChanged'] and not proof['databaseMigrated'] and not proof['productionScoreOperations']
proof.update(publicProof='nas-0.10.26-public-verification.json',serviceImage='yuepu-team-api:0.10.22',productionRoot='/data/expanded-0122',
             publisherProject='yuepu-app-0126',observedBusinessContainer='yuepu-team-api-0122-team-api-1 Up for 14 hours')
(out/'nas-0.10.26-deployment-verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
frozen=json.loads((w/'0126-full-inputs.json').read_text('utf-8'))
for n,h in frozen.items():assert digest(repo/n)==h,n
assert digest(out/'yuepuruanjian-0.10.26.apk')==expected['sha256']
source=out/'0.10.26-完整源码.zip';shutil.copy2(source,w/'0126-source-before-publication.zip')
names=json.loads((out/'0.10.26-源码校验.json').read_text('utf-8'))
manifest={n:dict(bytes=(repo/n).stat().st_size,sha256=digest(repo/n)) for n in sorted(names)}
assert 'desktop-organizer/AGENTS.md' in manifest
temporary=out/'0.10.26-source.tmp'
with zipfile.ZipFile(temporary,'x',zipfile.ZIP_DEFLATED) as z:
    for n in sorted(manifest):z.write(repo/n,'yuepuruanjian/'+n)
    z.writestr('SOURCE-SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(temporary) as z:
    assert z.testzip() is None
    for n,v in manifest.items():assert hashlib.sha256(z.read('yuepuruanjian/'+n)).hexdigest()==v['sha256']
temporary.replace(source)
(out/'0.10.26-源码校验.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
summary=json.loads((w/'0126-full-summary.json').read_text('utf-8'))
report=dict(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),android='0.10.26 (38)',full=summary,
    related=[dict(tests=20,classes=4),dict(tests=76,classes=14)],room=6,schemasUnchanged=True,service='0.10.22',database=4,naming=2,
    sourceInputs=len(frozen),sourceArchiveFiles=len(manifest),nasPublished=True,previousApp37Retained=True,
    publicProof='nas-0.10.26-public-verification.json',deploymentProof='nas-0.10.26-deployment-verification.json',
    workflow='Develop and local automated validation -> publish existing NAS APK channel and verify -> user updates/tests on physical device -> repair and republish',
    authorization='Human explicitly corrected the order and instructed publish first; ongoing same-scope APK workflow recorded in AGENTS section7',
    upload='All three files completed100%; browser timeout recovered in existing tab',
    publicationTest='First sandbox dependency ACL failure retained; escalated isolated real HTTP fixture passed retention/retry/tamper rejection',
    physicalAcceptance='pending user after published update',nativePersonalPdfAcceptance='compiled AndroidTest; not run',
    automation2='paused',multipleTeams='deferred roadmap19',productionScoreOperations=False,serviceRestarted=False,databaseMigrated=False)
(out/'0.10.26-完成验证.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
guide=out/'0.10.26-交付与验收说明.txt';previous=guide.read_text('utf-8')
shutil.copy2(guide,w/'0126-guide-before-publication.txt')
previous=previous.replace('0.10.26（38）候选交付','0.10.26（38）已发布交付')
previous=previous.replace('本候选尚未发布NAS。线上仍0.10.25（37），业务服务0.10.22、数据库4/命名2保持。本轮未重启服务、迁库或发起真实曲谱删除。',
    '0.10.26（38）已于2026-10-19 17:57中国时间发布NAS。旧0.10.25（37）包保留；NAS和电脑独立标准TLS完整安装包SHA/大小一致，20匿名私有接口401。业务服务0.10.22、数据库4/命名2保持，无重启、迁库或真实曲谱删除。')
previous=previous.replace('覆盖安装本候选后，','在App内检查更新并安装0.10.26后，')
previous+='\n后续固定顺序：开发与本机验证→先发布并核验更新渠道→用户本人真机更新验收反馈→修复再发布，已写AGENTS第7节；不会再把真机通过当发布前提。\n发布前0.10.26-验证报告.json的nasPublished=false为历史快照；当前实际上线以0.10.26-完成验证.json和nas-0.10.26-*-verification.json为准。源码包已同步本条规则及上线状态，旧候选源码快照保留在work供审计。\n'
guide.write_text(previous,encoding='utf-8')
with zipfile.ZipFile(out/'0.10.26-APK渠道发布工具.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((w/'0126-nas').iterdir()):
        if p.suffix!='.zip':z.write(p,p.name)
    for n in ('test_publish_app_0126.py','verify_public_0126_direct.py','prepare_publish_0126.py','complete_publish_0126.py'):z.write(w/n,n)
with zipfile.ZipFile(out/'0.10.26-NAS上线证据.zip','x',zipfile.ZIP_DEFLATED) as z:
    for n in ('nas-0.10.26-public-verification.json','nas-0.10.26-deployment-verification.json','nas-0.10.26-published.png','0.10.26-完成验证.json'):z.write(out/n,n)
    for n in ('0126-nas-deployment-dom.txt','0126-publisher-isolated-first.log','0126-publisher-isolated-second.log','0126-public-direct-first.log'):z.write(w/n,n)
for n in ('0.10.26-完整源码.zip','0.10.26-测试证据.zip','0.10.26-APK渠道发布工具.zip','0.10.26-NAS上线证据.zip'):
    with zipfile.ZipFile(out/n) as z:assert z.testzip() is None,n
files=[p for p in out.iterdir() if p.is_file() and '0.10.26' in p.name and p.name!='0.10.26-交付文件校验.json']
checks={p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(files)}
(out/'0.10.26-交付文件校验.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print('APP_0126_COMPLETE_AND_NAS_VERIFIED',len(checks),len(manifest),expected['sha256'])
