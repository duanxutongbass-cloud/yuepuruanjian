"""Stopped-writer migration and independent restores; no real team or score action."""
from pathlib import Path
from contextlib import closing
import hashlib,json,os,sqlite3
from backup_archive import plain_path,fingerprint
from app_release import AppReleases
from permanent_journal import sync_directory
import expanded_permanent as expanded
import multiteam_storage as storage

def save(path,value):
    with plain_path(path).open('x',encoding='utf-8') as out:
        json.dump(value,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())

def image_check(expected,app=Path('/app')):
    assert len(expected['serviceInputs'])==30
    for name,sha in expected['serviceInputs'].items():
        assert Path(name).name==name
        assert hashlib.sha256((app/name).read_bytes()).hexdigest()==sha,name
    from multiteam import MultiTeamDirectory,MultiTeamApplication
    from team_jobs import TeamCreationJobs
    assert storage.FORMAT=='score-team-multi-root-v1' and storage.ARCHIVE=='score-team-multi-backup-v1'

def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=lambda b:b.hex()).encode()

def snapshot(service):
    data=storage.business_snapshot(service)
    return dict(tables={n:dict(count=len(rows),sha256=hashlib.sha256(encoded(rows)).hexdigest()) for n,rows in data['tables'].items()},pdfs=data['pdfs'])

def accounts(path):
    result={}
    with closing(sqlite3.connect(plain_path(path).as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('BEGIN')
        for table in ('accounts','devices','sessions','invitations','account_memberships','membership_operations'):
            rows=db.execute('SELECT * FROM '+table+' ORDER BY rowid').fetchall()
            result[table]=dict(count=len(rows),sha256=hashlib.sha256(encoded(rows)).hexdigest())
    return result

def prepare(source,destination,expected,app=Path('/app')):
    image_check(expected,app);source=plain_path(source);destination=plain_path(destination)
    assert source!=destination and source.parent==destination.parent
    proof_path=destination/'deployment-0129.json'
    if proof_path.exists():
        proof=json.loads(proof_path.read_text('utf-8'));verify_proof(destination,proof,expected)
        assert proof['source']==str(source.resolve())
        print('MULTI_0129_PREPARE_ALREADY_VERIFIED',str(proof_path),flush=True);return proof
    service=expanded.open_active(source);before=snapshot(service);identity=accounts(service.path)
    previous=AppReleases(source).current()
    assert previous['versionCode']==40 and previous['sha256']==expected['previousSha256']
    activation=hashlib.sha256((source/'permanent-active.json').read_bytes()).hexdigest()
    result=storage.prepare(source,destination);primary=destination/'teams'/result['primaryTeam']
    assert snapshot(expanded.open_active(primary))==before
    assert accounts(destination/'identity/team.sqlite3')==identity
    # Exercise both the original complete backup and the new aggregate format.
    single=destination/'independent-single-restore'
    expanded.restore_archive(destination/'before-single-team.zip',single)
    assert snapshot(expanded.ExpandedPermanentStorage(single))==before
    complete=destination/'before-service-0129.zip';storage.create_archive(destination,complete)
    restored=destination/'independent-multi-restore';storage.restore_archive(complete,restored)
    assert snapshot(expanded.ExpandedPermanentStorage(restored/'teams'/result['primaryTeam']))==before
    storage.activate(restored,destination)
    assert storage._identity_business(restored)==storage._identity_business(destination)
    assert snapshot(expanded.open_active(restored/'teams'/result['primaryTeam']))==before
    # Keep the verified restore available for inspection, but never serve it.
    marker=json.loads((restored/storage.MARKER).read_text('utf-8'));marker['active']=False
    pending=restored/'multi-team.inspection-only';save(pending,marker);os.replace(pending,restored/storage.MARKER)
    sync_directory(restored)
    assert snapshot(service)==before and accounts(service.path)==identity
    assert AppReleases(source).current()==previous and AppReleases(destination).current()==previous
    assert hashlib.sha256((source/'permanent-active.json').read_bytes()).hexdigest()==activation
    proof=dict(source=str(source.resolve()),destination=str(destination.resolve()),primary=result['primaryTeam'],
        originalActivationSha256=activation,before=before,identity=identity,previousRelease=previous,
        singleBackup=fingerprint(destination/'before-single-team.zip'),multiBackup=fingerprint(complete),
        independentSingleRestore=True,independentMultiRestore=True,serviceInputs=expected['serviceInputs'],
        commonIdentitySha256=hashlib.sha256(encoded(storage._identity_business(destination))).hexdigest())
    save(proof_path,proof);verify_proof(destination,proof,expected)
    print('MULTI_0129_BACKUPS_INDEPENDENT_RESTORES_IDENTITIES_AND_BUSINESS_VERIFIED',len(before['pdfs']),str(proof_path),flush=True)
    return proof

def verify_proof(destination,proof,expected):
    root,marker=storage.checked_root(destination)
    assert proof['destination']==str(root.resolve()) and proof['primary']==marker['primary']
    assert proof['serviceInputs']==expected['serviceInputs']
    assert proof['independentSingleRestore'] and proof['independentMultiRestore']
    assert fingerprint(root/'before-single-team.zip')==proof['singleBackup']
    assert fingerprint(root/'before-service-0129.zip')==proof['multiBackup']
    assert snapshot(expanded.open_active(root/'teams'/marker['primary']))==proof['before']

def retire(source,destination,expected,app=Path('/app')):
    image_check(expected,app);proof=json.loads((destination/'deployment-0129.json').read_text('utf-8'))
    assert proof['source']==str(source.resolve());verify_proof(destination,proof,expected)
    result=storage.retire_source(source,destination,True)
    print('MULTI_0129_OLD_WRITER_RETIRED',json.dumps(result),flush=True);return result

def after(destination,expected,app=Path('/app')):
    image_check(expected,app);proof=json.loads((destination/'deployment-0129.json').read_text('utf-8'))
    verify_proof(destination,proof,expected)
    old=json.loads((Path(proof['source'])/'permanent-active.json').read_text('utf-8'))
    assert old['format']=='score-team-multi-redirect-v1' and old['directory']==str(destination.resolve())
    previous=AppReleases(destination).current()
    assert previous['versionCode']==40 and previous['sha256']==expected['previousSha256']
    print('MULTI_0129_LIVE_IMAGE_AND_PRESERVED_BUSINESS_VERIFIED',len(proof['before']['pdfs']),flush=True);return proof

def rollback(source,destination,expected,app=Path('/app')):
    """Only a stopped, unused deployment may return to the retained old writer."""
    image_check(expected,app);proof=json.loads((destination/'deployment-0129.json').read_text('utf-8'))
    assert proof['source']==str(source.resolve());verify_proof(destination,proof,expected)
    assert snapshot(expanded.ExpandedPermanentStorage(source))==proof['before']
    assert accounts(destination/'identity/team.sqlite3')==proof['identity'],'New identity activity requires manual preservation'
    assert hashlib.sha256(encoded(storage._identity_business(destination))).hexdigest()==proof['commonIdentitySha256']
    with closing(sqlite3.connect((destination/'identity/team.sqlite3').as_uri()+'?mode=ro',uri=True)) as db:
        assert db.execute('SELECT count(*) FROM mt_teams').fetchone()[0]==1,'New teams cannot be discarded by rollback'
        assert db.execute('SELECT count(*) FROM mt_jobs').fetchone()[0]==0,'Creation attempts require preservation'
    saved=(destination/'source-active-marker.json').read_bytes()
    assert hashlib.sha256(saved).hexdigest()==proof['originalActivationSha256']
    redirect=json.loads((source/'permanent-active.json').read_text('utf-8'))
    assert redirect['format']=='score-team-multi-redirect-v1' and redirect['directory']==str(destination.resolve())
    marker=json.loads((destination/storage.MARKER).read_text('utf-8'));marker['active']=False
    pending=destination/'multi-team.rollback-closed';save(pending,marker);os.replace(pending,destination/storage.MARKER)
    sync_directory(destination)
    pending=source/'permanent-active.rollback-pending'
    with pending.open('xb') as out:out.write(saved);out.flush();os.fsync(out.fileno())
    os.replace(pending,source/'permanent-active.json');expanded.open_active(source)
    sync_directory(source)
    print('MULTI_0129_UNUSED_DEPLOYMENT_ROLLBACK_VERIFIED',flush=True)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('phase',choices=('image','prepare','retire','after','rollback'))
    p.add_argument('--source-stopped',action='store_true');p.add_argument('--new-service-stopped',action='store_true');args=p.parse_args()
    assert os.getuid()==10001;os.umask(0o077)
    expected=json.loads(Path('/releases/0.10.29-inputs.json').read_text('utf-8'))
    source=Path('/data/expanded-0122');destination=Path('/data/multiteam-0129')
    if args.phase=='image':image_check(expected);print('MULTI_0129_IMAGE_PREFLIGHT_VERIFIED',flush=True)
    elif args.phase=='after':after(destination,expected)
    elif args.phase=='rollback':
        assert args.new_service_stopped,'Stop the new business container before rollback'
        rollback(source,destination,expected)
    else:
        assert args.source_stopped,'Stop the original business container before migration/retirement'
        (prepare if args.phase=='prepare' else retire)(source,destination,expected)
