from pathlib import Path
w=Path(__file__).resolve().parent
p=(w/'publish_app_0131.py').read_text('utf-8').replace('0.10.31','0.10.32').replace("['versionCode']==43","['versionCode']==44").replace('publish(apk,43,','publish(apk,44,').replace('app-0131-transfer','app-0132-transfer').replace('app-0131-','app-0132-').replace('APP_0131_','APP_0132_')
needle=' releases=AppReleases(root);before_path='
assert needle in p
p=p.replace(needle," def is_previous(value):\n  allowed=expected['previousReleases'].get(str(value['versionCode']))\n  return allowed is not None and all(value[k]==v for k,v in allowed.items())\n releases=AppReleases(root);before_path=")
needle="assert current['versionCode']==42 and current['sha256']==expected['previousSha256']";assert needle in p;p=p.replace(needle,'assert is_previous(current)')
needle="assert before['versionCode']==42 and before['sha256']==expected['previousSha256']";assert needle in p;p=p.replace(needle,'assert is_previous(before)')
line=next(line for line in p.splitlines() if 'value=releases.publish(' in line)
p=p.replace(line," value=releases.publish(apk,44,'0.10.32','修复新账号未创建或加入团队时缺少正常入口：直接开放个人曲库、节目单和我的导航，可进入账号与团队、应用更新及脚踏设置，无需先建团。团队内容仍按各团队审核与乐谱授权显示。包含已完成的阅读加载与自动分类改进；沿用原签名覆盖升级，保留账号、个人文件、曲谱和编号。')")
compile(p,'publish_app_0132.py','exec');(w/'publish_app_0132.py').write_text(p,encoding='utf-8',newline='\n')
p=(w/'verify_public_0131.py').read_text('utf-8').replace('0131-nas/0.10.31-inputs.json','0132-nas/0.10.32-inputs.json').replace('0.10.31','0.10.32').replace("['versionCode']==43","['versionCode']==44").replace('PUBLIC_0131_','PUBLIC_0132_')
compile(p,'verify_public_0132.py','exec');(w/'verify_public_0132.py').write_text(p,encoding='utf-8',newline='\n')
p=(w/'verify_app_0130.py').read_text('utf-8').replace('0130','0132').replace('0.10.30','0.10.32').replace('==337','==342').replace('==134','==136').replace('tests=785','tests=793').replace("versionCode='42'","versionCode='44'").replace('versionCode=42','versionCode=44')
p=p.replace("('DEBUG','TEST_OPERATION_LOGS','TEST_RELEASE_NOTES')","('DEBUG','HTTP_TEST','TEST_OPERATION_LOGS','TEST_RELEASE_NOTES')")
compile(p,'verify_app_0132.py','exec');(w/'verify_app_0132.py').write_text(p,encoding='utf-8',newline='\n')
p=(w/'prepare_tools_0130.py').read_text('utf-8').replace('0130','0132').replace('0.10.30','0.10.32').replace('versionCode=42','versionCode=44').replace('tests=785','tests=793')
needle="previousSha256='280d2e865fd3dfb1b540387819166e555b4b87a0d9452541a84ba3c1740a9eb0'";assert needle in p
p=p.replace(needle,"previousReleases={'42':dict(versionName='0.10.30',size=13992553,sha256='b734a1c0a645ea6870930a16310fab81bdcf1d70198332fb9979ddc8d799223a'),'43':dict(versionName='0.10.31',size=14008937,sha256='4323e8dc0fe9eb4751c7ece68300362944354ef6418cf93226a4fead5c9b338d')}")
compile(p,'prepare_tools_0132.py','exec');(w/'prepare_tools_0132.py').write_text(p,encoding='utf-8',newline='\n')
print('0132_APK_ONLY_HELPERS_CREATED')
