from pathlib import Path
import datetime,hashlib,json,urllib.request,urllib.error,uuid
w=Path(__file__).resolve().parent
expected=json.loads((w/'0132-nas/0.10.32-inputs.json').read_text('utf-8'))
origin='https://124355.xyz:18443'
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
with opener.open(origin+'/v1/app-release',timeout=30) as response:
    assert response.url==origin+'/v1/app-release' and response.status==200
    manifest=json.load(response)
print('PUBLIC_MANIFEST',json.dumps(manifest,ensure_ascii=False),flush=True)
assert manifest['versionCode']==44 and manifest['versionName']=='0.10.32' and manifest['sha256']==expected['sha256'] and manifest['size']==expected['size']
request=urllib.request.Request(origin+'/v1/app-release/apk',headers={'If-Match':'"'+expected['sha256']+'"'})
with opener.open(request,timeout=30) as response:
    assert response.url==origin+'/v1/app-release/apk' and response.status==200
    assert response.headers.get('Content-Length')==str(expected['size'])
    assert response.headers.get('ETag')=='"'+expected['sha256']+'"'
    size=0;h=hashlib.sha256()
    while chunk:=response.read(65536):size+=len(chunk);h.update(chunk)
assert size==expected['size'] and h.hexdigest()==expected['sha256']
private={}
for route in ('/v1/catalog','/v2/catalog','/v1/admin/capabilities','/v2/admin/capabilities','/v1/me/teams','/v1/me/team-operations/'+str(uuid.uuid4())):
    try:
        with opener.open(origin+route,timeout=30) as response:status=response.status
    except urllib.error.HTTPError as error:status=error.code
    private[route]=status;assert status==401,(route,status)
report=dict(verifiedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),origin=origin,normalTlsValidation=True,redirectsAllowed=False,release=manifest,fullDownload=dict(size=size,sha256=h.hexdigest()),contentLengthAndETagMatched=True,privateEndpoints=private,physicalAcceptance='待用户本人验收')
(w.parent/'outputs/0.10.32-公网发布核验.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('PUBLIC_0132_NORMAL_TLS_FULL_APK_AND_PRIVATE_ROUTES_VERIFIED',flush=True)
