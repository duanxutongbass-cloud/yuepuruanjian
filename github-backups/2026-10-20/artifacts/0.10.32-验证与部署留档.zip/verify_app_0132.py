from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as ET,re
w=Path(__file__).resolve().parent;r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
inputs=json.loads((w/'0132-full-inputs.json').read_text('utf-8'))
assert len(inputs)==342 and all(hashlib.sha256((r/n).read_bytes()).hexdigest()==sha for n,sha in inputs.items())
log=(w/'0132-app-full-first.log').read_text('utf-8',errors='replace');assert 'BUILD SUCCESSFUL' in log
xmls=sorted((r/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'))
summary=dict(tests=0,failures=0,errors=0,skipped=0)
for path in xmls:
    suite=ET.parse(path).getroot()
    for key in summary:summary[key]+=int(suite.attrib.get(key,0))
assert len(xmls)==136 and summary==dict(tests=793,failures=0,errors=0,skipped=0),summary
lint={}
for mode in ('debug','release'):
    path=r/f'app/build/reports/lint-results-{mode}.xml';issues=list(ET.parse(path).getroot())
    errors=[i for i in issues if i.attrib.get('severity') in ('Error','Fatal')];assert not errors
    lint[mode]=dict(errors=0,warnings=sum(i.attrib.get('severity')=='Warning' for i in issues))
signature=(w/'0132-final-signature.txt').read_text('utf-8',errors='replace')
assert 'Verified using v2 scheme (APK Signature Scheme v2): true' in signature
assert '9f360690612dabcdc4c13c8fb0b89af99402a64782f8fdcba79cddfb2be745fa' in signature
badging=(w/'0132-final-badging.txt').read_text('utf-8',errors='replace')
assert "name='com.ensemble.scorelibrary'" in badging and "versionCode='44'" in badging and "versionName='0.10.32'" in badging
assert 'application-debuggable' not in badging
config=(r/'app/build/generated/source/buildConfig/release/com/ensemble/scorelibrary/BuildConfig.java').read_text('utf-8')
for flag in ('DEBUG','HTTP_TEST','TEST_OPERATION_LOGS','TEST_RELEASE_NOTES'):
    assert re.search(r'boolean '+flag+r' = false;',config),flag
proof=dict(versionName='0.10.32',versionCode=44,tests=summary,classes=len(xmls),lint=lint,inputFiles=len(inputs),inputsUnchanged=True,
    roomSchemaUnchanged=True,releaseNonDebuggable=True,operationLogs=False,testReleaseHistory=False,existingCertificatePreserved=True,
    certificateSha256='9f360690612dabcdc4c13c8fb0b89af99402a64782f8fdcba79cddfb2be745fa',
    coverageUpgradeRequirements='same applicationId/certificate; higher versionCode; unchanged Room schema',physicalAcceptance='pending user after NAS publication',published=False)
out=w.parent/'outputs'
for source,name in ((r/'app/build/outputs/apk/release/app-release.apk','yuepuruanjian-0.10.32-release.apk'),
                    (r/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk','yuepuruanjian-0.10.32-androidTest.apk')):
    raw=source.read_bytes();target=out/name;target.write_bytes(raw);assert target.read_bytes()==raw
    proof[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
evidence=w/'0132-app-full-results';evidence.mkdir(exist_ok=True)
for p in xmls:shutil.copyfile(p,evidence/p.name)
(w/'0132-app-full-summary.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
(out/'0.10.32-App本机验证.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
print('APP_0132_FORMAL_BUILD_AND_FULL_REGRESSION_VERIFIED',json.dumps(proof,ensure_ascii=False))
