"""Both supported prior real APK channels; isolated synthetic team data only."""
from pathlib import Path
import sys,importlib.util,json,threading
w=Path(__file__).resolve().parent;r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service');sys.path.insert(0,str(r))
from test_expanded_permanent import ExpandedPermanentTest
from app_release import AppReleases
from multiteam import MultiTeamDirectory,MultiTeamApplication
import expanded_permanent
from waitress import create_server
def load(name,file):
 s=importlib.util.spec_from_file_location(name,w/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
helper=load('migration0129','service_patch_0129.py');publishers={n:load('publisher'+n,'publish_app_'+n+'.py') for n in ('0129','0130','0131','0132')}
inputs={n:json.loads((w/(n+'-nas')/('0.10.'+n[-2:]+'-inputs.json')).read_text('utf-8')) for n in publishers}
cases=[]
for old_code in (42,43):
 f=ExpandedPermanentTest();f.setUp()
 try:
  AppReleases(f.target).publish(w.parent/'outputs/yuepuruanjian-0.10.28-number-release.apk',40,'0.10.28','Synthetic fixture')
  root=f.root/'multi';helper.prepare(f.target,root,inputs['0129'],r);helper.retire(f.target,root,inputs['0129'],r)
  directory=MultiTeamDirectory(root);server=create_server(MultiTeamApplication(directory,True),host='127.0.0.1',port=0,threads=4)
  worker=threading.Thread(target=server.run,daemon=True);worker.start()
  try:
   kw=dict(origin=f'http://127.0.0.1:{server.effective_port}',allow_test_http=True)
   for n in (('0129','0130') if old_code==42 else ('0129','0130','0131')):
    publishers[n].publish_bundle(root,w/(n+'-nas')/('app-'+n+'-transfer.zip'),inputs[n],**kw)
   before=AppReleases(root).current();assert before['versionCode']==old_code
   primary=root/'teams'/directory.marker['primary'];business=helper.snapshot(expanded_permanent.open_active(primary));identity=helper.accounts(root/'identity/team.sqlite3')
   candidate=inputs['0132'];bundle=w/'0132-nas/app-0132-transfer.zip';publisher=publishers['0132']
   receipt=publisher.publish_bundle(root,bundle,candidate,**kw);assert publisher.publish_bundle(root,bundle,candidate,**kw)==receipt
   wrong_previous=dict(candidate,previousReleases={k:dict(v,sha256='0'*64) for k,v in candidate['previousReleases'].items()})
   for wrong in (dict(candidate,bundleSha256='0'*64),dict(candidate,sha256='0'*64),wrong_previous):
    try:publisher.publish_bundle(root,bundle,wrong,**kw);raise RuntimeError('Tampered publication accepted')
    except AssertionError:pass
   assert helper.snapshot(expanded_permanent.open_active(primary))==business and helper.accounts(root/'identity/team.sqlite3')==identity
   assert helper.fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
   cases.append(dict(previousVersionCode=old_code,newVersionCode=44,oldApkRetained=True,repeatIdempotent=True,tamperRejected=True,businessAndIdentityUnchanged=True))
  finally:server.task_dispatcher.shutdown();server.close();worker.join(10)
 finally:f.doCleanups()
report=dict(isolated=True,realApks=True,localHttpOnly=True,productionTouched=False,cases=cases,sha256=inputs['0132']['sha256'])
(w/'0132-publication-isolated-verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('APP_0132_REAL_42_AND_43_TO_44_CHANNEL_RETRY_TAMPER_PRESERVATION_PASS',flush=True)
