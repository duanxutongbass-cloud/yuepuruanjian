from pathlib import Path
import sys,json,hashlib,importlib.util
w=Path(__file__).resolve().parent
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service')
sys.path.insert(0,str(repo))
from app_release import AppReleases
spec=importlib.util.spec_from_file_location('patch0127',w/'service_patch_0127.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
root=w/'nas-migration-test-fifth/data/expanded-0122'
old=AppReleases(root).current();assert old['versionCode']==38
names=json.loads((w/'nas-0122/number13-release-inputs.json').read_text('utf-8'))['serviceInputs']
inputs={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in names}
expected=dict(serviceInputs=inputs,previousSha256=old['sha256'],sha256='0'*64)
before=module.snapshot(root)
proof=module.prepare(root,expected,repo)
assert proof['independentRestore'] and proof['before']==before
assert module.prepare(root,expected,repo)==proof
assert module.after(root,expected,repo)==proof
bad=dict(expected,serviceInputs=dict(inputs,**{'annotations.py':'0'*64}))
try:module.prepare(root,bad,repo);raise AssertionError('Damaged image accepted')
except AssertionError as error:
    if str(error)=='Damaged image accepted':raise
assert module.snapshot(root)==before and AppReleases(root).current()==old
print('SERVICE_0127_ISOLATED_BACKUP_RESTORE_RETRY_IMAGE_REJECTION_VERIFIED',len(before['pdfs']))
