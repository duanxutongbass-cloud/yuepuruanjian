"""APK-channel update only. The running service and database are never migrated."""
from pathlib import Path
from contextlib import closing
import hashlib,json,os,sqlite3,urllib.request,urllib.error,uuid,zipfile,tempfile
from app_release import AppReleases

def fingerprint(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as source:
  while block:=source.read(65536):h.update(block);size+=len(block)
 return dict(size=size,sha256=h.hexdigest())

def publish(root,apk,expected,origin='https://124355.xyz:18443',allow_test_http=False):
 assert origin=='https://124355.xyz:18443' or allow_test_http and origin.startswith('http://127.0.0.1:')
 assert root.is_dir() and not root.is_symlink()
 marker=json.loads((root/'expanded-permanent-storage.json').read_text('utf-8'))
 active=json.loads((root/'permanent-active.json').read_text('utf-8'))
 with closing(sqlite3.connect((root/'team.sqlite3').as_uri()+'?mode=ro',uri=True)) as db:
  db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
  assert db.execute('PRAGMA user_version').fetchone()[0]==4
  metadata=dict(db.execute('SELECT key,value FROM metadata'))
  assert metadata['scoreNamingVersion']=='2' and metadata['numberingCandidateRoot']==str(root.resolve())
  assert metadata['numberingCandidateId']==marker['storageId']==active['storageId']
  assert active['teamId']==metadata['teamId'] and marker['format']=='score-team-expanded-permanent-storage-v1'
 assert expected['versionCode']==39 and expected['versionName']=='0.10.27'
 assert fingerprint(apk)==dict(size=expected['size'],sha256=expected['sha256'])
 releases=AppReleases(root);before_path=root/'app-releases/before-0.10.27.json'
 current=releases.current()
 if before_path.exists():before=json.loads(before_path.read_text('utf-8'))
 else:
  assert current['versionCode']==38 and current['sha256']==expected['previousSha256']
  before=current
  with before_path.open('x',encoding='utf-8') as out:json.dump(before,out,ensure_ascii=False);out.flush();os.fsync(out.fileno())
 assert before['versionCode']==38 and before['sha256']==expected['previousSha256']
 assert fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
 assert current==before or current['versionCode']==39 and current['sha256']==expected['sha256']
 def get(path,binary=False):
  request=urllib.request.Request(origin+path,headers=({'If-Match':'"'+expected['sha256']+'"'} if binary else {}))
  try:response=urllib.request.urlopen(request,timeout=30)
  except urllib.error.HTTPError as error:return error.code,None
  with response:
   assert response.url==origin+path,'Redirect refused'
   if not binary:return response.status,json.load(response)
   digest=hashlib.sha256();size=0
   while block:=response.read(65536):digest.update(block);size+=len(block)
   return response.status,dict(size=size,sha256=digest.hexdigest())
 status,public=get('/v1/app-release');assert status==200 and public['versionCode']==current['versionCode'] and public['sha256']==current['sha256']
 for route in ('/v1/catalog','/v2/catalog','/v1/admin/capabilities','/v2/admin/capabilities'):
  assert get(route)[0]==401,'Private access unexpectedly allowed'
 value=releases.publish(apk,39,'0.10.27','15号手写笔：可开启逐点压感粗细，并选择主/副侧键按住临时整笔擦除，支持撤销；笔画中换键取消未完成动作。设置默认关闭，工具栏手写笔设置开启，仅使用系统实际笔输入。压感随保存、恢复、同步保留，旧笔迹不变。兼容服务已先更新；旧客户端需更新后编辑压感页。保留26曲库和回收站改进。')
 status,public=get('/v1/app-release');assert status==200 and public['versionCode']==39 and public['sha256']==expected['sha256']
 status,download=get('/v1/app-release/apk',True);assert status==200 and download==dict(size=expected['size'],sha256=expected['sha256'])
 assert fingerprint(root/'app-releases'/(before['sha256']+'.apk'))==dict(size=before['size'],sha256=before['sha256'])
 report=dict(release=value,previousReleaseRetained=True,fullPublicDownload=download,serviceChanged=False,databaseMigrated=False,
  productionScoreOperations=False,physicalAcceptance='pending user',backup=str(before_path))
 proof=root/'app-releases/0.10.27-publication-proof.json'
 if proof.exists():assert json.loads(proof.read_text('utf-8'))==report
 else:
  with proof.open('x',encoding='utf-8') as out:json.dump(report,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())
 print('APP_0127_PUBLISHED_AND_FULL_HTTPS_VERIFIED',json.dumps(report,ensure_ascii=False),flush=True)
 return report

def publish_bundle(root,bundle,expected,**options):
 assert fingerprint(bundle)==dict(size=expected['bundleSize'],sha256=expected['bundleSha256'])
 with zipfile.ZipFile(bundle) as z:
  rows=z.infolist();assert len(rows)==1 and rows[0].filename=='app.apk' and not rows[0].is_dir()
  assert rows[0].file_size==expected['size'] and rows[0].file_size<=256*1024*1024
  with tempfile.TemporaryDirectory(prefix='app-0127-') as directory:
   apk=Path(directory)/'app.apk'
   with z.open(rows[0]) as source,apk.open('xb') as target:
    count=0
    while block:=source.read(65536):
     count+=len(block);assert count<=expected['size'];target.write(block)
   assert count==expected['size']
   return publish(root,apk,expected,**options)

if __name__=='__main__':
 assert os.getuid()==10001
 folder=Path('/releases');expected=json.loads((folder/'0.10.27-final-inputs.json').read_text('utf-8'))
 publish_bundle(Path('/data/expanded-0122'),folder/'app-0127-final-transfer.zip',expected)
