from pathlib import Path
import datetime,hashlib,json,runpy,zipfile
r=Path(__file__).resolve().parent.parent;w=r/'work';out=r/'outputs'
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((w/'0127-nas/0.10.27-final-inputs.json').read_text('utf-8'))
raw=(w/'0127-nas-release-log.txt').read_text('utf-8')
def marker(name):
    start=raw.index(name)+len(name)
    return json.JSONDecoder().raw_decode(raw[start:].lstrip())[0]
app=marker('APP_0127_PUBLISHED_AND_FULL_HTTPS_VERIFIED')
service=marker('SERVICE_0127_DEPLOYED_AND_APP_PUBLISHED')
assert service['serviceUpdated'] and not service['databaseMigrated'] and service['independentRestore'] and service['sourceInputs']==25
assert 'SERVICE_0127_LIVE_DATA_AND_IMAGE_VERIFIED' in raw
stopped=(w/'0127-nas-old-service-stopped-final.txt').read_text('utf-8')
assert 'yuepu-team-api-0122-team-api-1' in stopped and 'generic: 已停止' in stopped
assert 'SERVICE_0127_BACKUP_AND_INDEPENDENT_RESTORE_VERIFIED' in (w/'0127-nas-prepare-log.txt').read_text('utf-8')
public=json.loads((out/'nas-0.10.27-public-verification.json').read_text('utf-8'))
assert dict(app['release'],available=True)==public['metadata']
assert app['previousReleaseRetained'] and app['fullPublicDownload']==public['fullDownload']==dict(size=expected['size'],sha256=expected['sha256'])
assert len(public['anonymousPrivate'])==20 and all(v==401 for v in public['anonymousPrivate'].values())
assert public['serviceChanged'] and not app['productionScoreOperations'] and not app['databaseMigrated']
for n,h in json.loads((w/'0127-full-inputs.json').read_text('utf-8')).items():assert digest(repo/n)==h,n
assert digest(out/'yuepuruanjian-0.10.27-stylus.apk')==expected['sha256']
proof=dict(app=app,service=service,publicProof='nas-0.10.27-public-verification.json',serviceImage='yuepu-team-api:0.10.27',
    previousServiceImage='yuepu-team-api:0.10.22',productionRoot='/data/expanded-0122',businessProject='yuepu-team-api-0127-final',
    previousBusinessStopped=True,backup='/data/expanded-0122/backups/before-service-0127-v2/backup.zip',
    backupProof='/data/expanded-0122/backups/before-service-0127-v2/verified.json',databaseMigrated=False,productionScoreOperations=False,
    registeredSourcePdfs=service['pdfs'],
    initialDeploymentFailure='First prepare blocked on permanent_deletion_jobs storageId rebinding in independent restore; no new business started or APK published; old service resumed; read-only diagnosis found only that table differed and PDFs equal. Strict own-storage-only normalization added to helper v2 and synthetic deletion-history backup/restore/retry/tamper rejection passed. New backup directory used for final deployment.',
    note='APK component serviceChanged=false describes its channel-only operation; overall service was updated22->27 before APK publication')
(out/'nas-0.10.27-deployment-verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
status='2026-10-19 编号15本轮已发布0.10.27（39）：可选逐点压感、主/副侧键临时整笔擦除和升级队列/旧基线兼容完成。App757项/125类、服务248项覆盖通过，Lint0错误22警告，323份App输入及同签名保持。NAS服务22→27仅兼容批注解析，无迁库，原根/data/expanded-0122、库4/命名2保留；当次完整备份、独立恢复、业务行/原PDF哈希核验后发布39，旧38包保留。NAS与电脑独立标准TLS整包22080609字节、SHA6b0506bf7926c72a90ed5a32d9891fa3a47766cd152e4ebb982594cdd09dcd49一致、20私有401。待用户本人从应用更新升级实测压感/侧键，各物理笔/延迟未代验收；先发布→本人验收顺序保持。无真实谱删除/旧13迁移重跑/新权限/并行代理；多团队19后续、automation-2暂停。'
p=repo/'desktop-organizer/PROGRESS.md';text=p.read_text('utf-8');heading='# 开发进度（先读本页，再按需查历史）';assert text.startswith(heading)
p.write_text(text.replace(heading,heading+'\n\n'+status,1),encoding='utf-8')
p=repo/'docs/NUMBERED_DEVELOPMENT.md';text=p.read_text('utf-8');old=next(l for l in text.splitlines() if l.startswith('| 15 |'))
new='| 15 | 手写笔专项适配 | 本轮0.10.27(39)已发布：可选逐点压感、主/副侧键临时整笔擦除、保存/恢复/同步及升级兼容；App757/服务248通过，NAS备份独立恢复及整包核验完成。物理笔/设备/延迟待用户更新后本人验收，见STYLUS_0127.md；厂商未上报专有手势不模拟 |'
p.write_text(text.replace(old,new),encoding='utf-8')
p=repo/'docs/STYLUS_INPUT.md';text=p.read_text('utf-8');old=text.splitlines()[0]
text=text.replace(old,'# 编号15：手写笔输入',1)
text=text.replace('\n\n','\n\n当前状态（2026-10-19）：0.10.27（39）已发布，压感/主副侧键、保存恢复同步及升级兼容完成；App757项、服务248项覆盖通过，NAS备份独立恢复和标准TLS整包核验完成。使用与实际边界见[0.10.27](STYLUS_0127.md)，物理手写笔仍由用户更新后本人验收。以下0.10.13候选内容为历史记录，不能当作当前待办或线上版本。\n\n',1)
p.write_text(text,encoding='utf-8')
p=repo/'docs/STYLUS_0127.md';text=p.read_text('utf-8');text=text.replace('\n\n','\n\n发布状态：0.10.27（39）已上线既有NAS更新渠道，兼容服务27先于APK发布；当次完整备份、独立恢复和原业务行/PDF核对通过，公网整包SHA/大小一致、20匿名私有401。旧38包与旧服务容器保留，旧业务容器停止；原根、库4/命名2不迁移。真机验收待用户本人更新后反馈。\n\n',1);p.write_text(text,encoding='utf-8')
p=repo/'docs/README.md';text=p.read_text('utf-8');text=text.replace('\n\n','\n\n2026-10-19 当前已发布0.10.27（39）：编号15逐点压感和可配置主/副侧键临时整笔擦除，App757/服务248项覆盖通过。NAS兼容服务27、当次备份/独立恢复、整包核验完成，真机由用户升级后本人验收，详见[手写笔27](STYLUS_0127.md)。下方各旧候选状态保留为历史。\n\n',1);p.write_text(text,encoding='utf-8')
runpy.run_path(str(w/'package_0127.py'),run_name='__main__')
full=json.loads((w/'0127-full-summary.json').read_text('utf-8'));sv=json.loads((w/'0127-service-full-summary.json').read_text('utf-8'))
manifest=json.loads((out/'0.10.27-源码校验.json').read_text('utf-8'))
report=dict(completedAt=now,android='0.10.27 (39)',full=full,serviceFull=sv,sourceInputs=323,sourceArchiveFiles=len(manifest),
    related=[dict(tests=61,classes=8),dict(tests=19,classes=3)],room=6,schemasUnchanged=True,service='0.10.27',database=4,naming=2,
    nasPublished=True,previousApp38Retained=True,serviceUpdated=True,databaseMigrated=False,productionScoreOperations=False,
    workflow='Develop/local validation -> publish NAS and verify -> user personally updates/tests -> repair and republish',
    physicalAcceptance='pending user after published update',nativePersonalPdfAcceptance='AndroidTest compiled; physical device not run',
    automation2='paused',multipleTeams='deferred roadmap19',upload='Final three files verified complete and moved to releases before stopping old service',
    serviceBackup='Full archive and independent restore from current root before startup; business rows and source PDF fingerprints preserved',
    registeredSourcePdfs=service['pdfs'],helperV2Test='Real synthetic v4 deletion history: reproduce old helper mismatch, strict rebinding normalization, independent restore, retry, business field/storage binding/image tamper rejection passed',
    publicationProof='nas-0.10.27-deployment-verification.json',publicProof='nas-0.10.27-public-verification.json',
    failuresRetained=['Pressure contour winding failure fixed/retested61','Queued fixture host HttpServer unavailable; standard ServerSocket fixture passed19',
        'First full command wrong cwd retained','Service fixture missing PYTHONPATH: original247 pass/1fail; that same case retested pass',
        'First NAS prepare false mismatch from restored deletion plan storageId rebinding; blocked before new service/APK; fixed helper v2 and fresh backup passed',
        'New helper fixture first missing dependency path, then invalid synthetic APK ZIP; third complete test passed; all logs retained'],
    limits=['Only system-reported stylus pressure/primary-secondary buttons','No proprietary pen gestures or physical latency acceptance',
        'Personal local PDF reader does not yet support these annotations'])
(out/'0.10.27-完成验证.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'0.10.27-交付与验收说明.txt').write_text('''曲谱库0.10.27（39）已发布，编号15本轮交付

从“我的→应用更新”升级。看谱工具栏→手写笔设置，可开启压感、选择主侧键或副侧键；新选项默认关闭。
用支持系统笔输入的笔，选择手写工具，轻重落笔应粗细变化；保存、重开或同步后保留。按所选侧键再落笔可临时整笔擦除，抬笔回到原工具，可以撤销。落笔中改变侧键会取消未完成动作，重新落笔后开始。
由你本人升级后验收：轻重笔、重新打开、同步、撤销、主/副侧键、笔掌分离与取消；若设备未上报压感/按键，请反馈笔型号和现象。厂商专有双击、蓝牙自定义手势与物理时延未保证，普通触摸笔无法被程序猜成系统手写笔。个人PDF区目前仍是本机基础阅读器，未接入这些批注。

验证：完整App757项/125类，0失败/错误/跳过，APK/AndroidTest/Lint通过，Lint0错误22警告；完整服务28文件248项覆盖通过（原批247过1环境导入失败，补齐夹具路径后同项通过，失败日志保留）。61项输入相关及19项升级相关通过，不与完整全集重复相加。323份App输入哈希固定，同原签名；Windows源码和Room6保持。
NAS服务22→27仅批注兼容解析，数据库4/命名2、原数据根保持。完整备份、独立恢复及原业务行/PDF哈希核对后才发布App39，旧38包/旧镜像和停止的旧容器保留，无迁库或真实曲谱删除。新压感写入后不能盲目回退旧解析器。NAS与电脑独立标准TLS整包核验一致，20个私有匿名请求401。
主包22080609字节，SHA256 6b0506bf7926c72a90ed5a32d9891fa3a47766cd152e4ebb982594cdd09dcd49。
发布首轮恢复比较因删除台账的合法存储标识换绑误报，被门禁阻止，新服务/APK均未启动发布；原服务恢复后只读确认只有该表不同、PDF一致。辅助脚本v2仅归一化经核验的自身存储标识，业务字段仍逐项比较；真实合成删除历史备份/恢复/重试/篡改拒绝通过，再以新备份目录切换成功。失败日志及原备份保留，不把失败当通过。当前NAS登记的原PDF数为0，业务表和删除台账已核验，未将历史5份PDF冒充本次仍存在。

完整源码ZIP含既有Android/服务/Windows工程、真实测试及原启动打包说明；AndroidTest APK仅编译封存，未代操作物理平板。Windows本轮未改，不把既有EXE当成本次新开发。测试证据包含实际失败和修正后结果。发布前验证报告nasPublished=false为历史快照，实际已上线以完成验证、NAS部署/公网报告及截图为准。
后续仍按开发/本机验证→先发布核验→用户本人真机反馈→修复再发布；多团队并编号19后续整体开发，automation-2暂停。
''',encoding='utf-8')
with zipfile.ZipFile(out/'0.10.27-部署发布工具.zip','x',zipfile.ZIP_DEFLATED) as z:
    for n in ('compose-live-0127-v2.yaml','0.10.27-final-inputs.json','publish-app-0127-final.py','0127-service-inputs.json','service-patch-0127-v2.py','compose-image-0127.yaml'):
        p=w/'0127-nas'/n
        if p.exists():z.write(p,n)
    for n in ('service_patch_0127.py','test_service_patch_0127.py','service_patch_0127_v2.py','test_service_patch_0127_v2.py','prepare_helper_v2_0127.py','test_publish_app_0127.py','verify_public_0127_direct.py','prepare_image_0127.py','prepare_final_release_0127.py','complete_publish_0127.py'):z.write(w/n,n)
    for p in sorted((w/'0127-nas/service-0127-patch').glob('*')):
        if p.is_file():z.write(p,'service-0127-patch/'+p.name)
with zipfile.ZipFile(out/'0.10.27-NAS上线证据.zip','x',zipfile.ZIP_DEFLATED) as z:
    for n in ('nas-0.10.27-public-verification.json','nas-0.10.27-deployment-verification.json','nas-0.10.27-published.png','0.10.27-完成验证.json'):z.write(out/n,n)
    for pattern in ('0127-nas-*.txt','0127-public-direct*.log','0127-publisher-isolated*.log','0127-service-patch-isolated*.log'):
        for p in sorted(w.glob(pattern)):z.write(p,p.name)
for p in out.glob('0.10.27-*.zip'):
    with zipfile.ZipFile(p) as z:assert z.testzip() is None,p.name
files=[p for p in out.iterdir() if p.is_file() and '0.10.27' in p.name and p.name!='0.10.27-交付文件校验.json']
(out/'0.10.27-交付文件校验.json').write_text(json.dumps({p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(files)},ensure_ascii=False,indent=2),encoding='utf-8')
print('APP_0127_COMPLETE_AND_NAS_VERIFIED',len(files),len(manifest),expected['sha256'])
