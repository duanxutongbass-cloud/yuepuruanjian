from pathlib import Path
import hashlib
w=Path(__file__).resolve().parent;stage=w/'0127-nas'
raw=(w/'service_patch_0127.py').read_text('utf-8')
old="""            if table=='metadata':records=[r for r in records if r[0] not in {'numberingCandidateRoot','numberingCandidateId'}]
"""
new=old+"""            if table=='permanent_deletion_jobs':
                columns=[row[1] for row in db.execute('PRAGMA table_info(permanent_deletion_jobs)')]
                index=columns.index('plan')
                for record in records:
                    plan=json.loads(record[index])
                    assert plan['storageId']==metadata['numberingCandidateId'],'Deletion plan storage binding mismatch'
                    plan['storageId']='<verified-own-storage>'
                    record[index]=json.dumps(plan,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
"""
assert raw.count(old)==1
raw=raw.replace(old,new).replace('before-service-0127','before-service-0127-v2')
assert 'before-service-0127-v2' in raw
(w/'service_patch_0127_v2.py').write_text(raw,encoding='utf-8',newline='\n')
(stage/'service-patch-0127-v2.py').write_bytes(raw.encode('utf-8'))
sha=hashlib.sha256(raw.encode('utf-8')).hexdigest()
compose=(stage/'compose-live-0127-final.yaml').read_text('utf-8')
compose=compose.replace('service-patch-0127.py','service-patch-0127-v2.py').replace('176d2c3f7c1a7f768afc67628ac42834cdb3e01abf7533f7286a47502267c3df',sha)
(stage/'compose-live-0127-v2.yaml').write_text(compose,encoding='utf-8',newline='\n')
print('SERVICE_0127_HELPER_V2_PREPARED',sha)
