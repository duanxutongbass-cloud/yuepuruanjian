from pathlib import Path
import hashlib,json,importlib.util,sys,sqlite3
from zipfile import ZipFile,ZIP_DEFLATED
w=Path(__file__).resolve().parent
repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service')
sys.path.insert(0,str(repo))
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,w/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=module('oldhelper','service_patch_0127.py');new=module('newhelper','service_patch_0127_v2.py')
from test_expanded_permanent import ExpandedPermanentTest
from app_release import AppReleases
fixture=ExpandedPermanentTest()
fixture.setUp()
try:
    root=fixture.target
    # Only this named synthetic test fixture is deleted, never NAS/real scores.
    aid,_=fixture.staged('01-01-1000');fixture.publish([aid]);fixture.delete(aid)
    folder=root/'app-releases';folder.mkdir(exist_ok=True)
    synthetic=w/'synthetic-helper-v2-not-installable.apk'
    with ZipFile(synthetic,'w',ZIP_DEFLATED) as z:
        z.writestr('AndroidManifest.xml',b'Synthetic manifest for service helper validation only')
        z.writestr('classes.dex',b'Synthetic dex not installable')
    AppReleases(root).publish(synthetic,38,'0.10.26','Synthetic only')
    current=AppReleases(root).current()
    names=json.loads((w/'0127-nas/0.10.27-final-inputs.json').read_text('utf-8'))['serviceInputs']
    inputs={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in names}
    expected=dict(serviceInputs=inputs,previousSha256=current['sha256'],sha256='0'*64)
    before=new.snapshot(root)
    proof=new.prepare(root,expected,repo)
    restored=root/'backups/before-service-0127-v2/independent-restore'
    a,b=old.snapshot(root),old.snapshot(restored)
    diffs=[k for k in a['tables'] if a['tables'][k]!=b['tables'].get(k)]
    assert diffs==['permanent_deletion_jobs'] and a['pdfs']==b['pdfs'],diffs
    assert new.snapshot(restored)==before and new.snapshot(root)==before
    assert new.prepare(root,expected,repo)==proof and new.after(root,expected,repo)==proof
    with sqlite3.connect(restored/'team.sqlite3') as db:
        encoded=db.execute('SELECT plan FROM permanent_deletion_jobs').fetchone()[0]
        plan=json.loads(encoded);plan['revision']+=1
        db.execute('UPDATE permanent_deletion_jobs SET plan=?',(json.dumps(plan),))
    assert new.snapshot(restored)!=before,'Business plan change must not be ignored'
    with sqlite3.connect(restored/'team.sqlite3') as db:
        plan=json.loads(encoded);plan['storageId']='00000000-0000-0000-0000-000000000000'
        db.execute('UPDATE permanent_deletion_jobs SET plan=?',(json.dumps(plan),))
    try:new.snapshot(restored);raise RuntimeError('Wrong storage binding accepted')
    except AssertionError as error:assert 'binding mismatch' in str(error)
    assert new.snapshot(root)==before and AppReleases(root).current()==current
    bad=dict(expected,serviceInputs=dict(inputs,**{'annotations.py':'0'*64}))
    try:new.after(root,bad,repo);raise RuntimeError('Damaged image accepted')
    except AssertionError as error:assert 'annotations.py' in str(error)
    print('SERVICE_0127_V2_REAL_DELETION_HISTORY_BACKUP_RESTORE_RETRY_TAMPER_REJECTION_VERIFIED',len(before['pdfs']),diffs)
finally:fixture.doCleanups()
