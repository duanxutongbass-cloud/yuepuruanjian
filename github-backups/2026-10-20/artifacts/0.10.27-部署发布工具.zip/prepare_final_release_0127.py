from pathlib import Path
import json,re,hashlib,zipfile
w=Path(__file__).resolve().parent;out=w.parent/'outputs';stage=w/'0127-nas'
report=json.loads((out/'0.10.27-验证报告.json').read_text('utf-8'))
assert report['tests']==757 and report['serviceFull']['tests']==248
apk=out/'yuepuruanjian-0.10.27-stylus.apk'
assert apk.stat().st_size==report['size'] and hashlib.sha256(apk.read_bytes()).hexdigest()==report['sha256']
def adapt(text):
    text=text.replace('0.10.26','0.10.27').replace('0126','0127')
    return re.sub(r'\b(37|38)\b',lambda m:{'37':'38','38':'39'}[m[0]],text)
publisher=adapt((w/'publish_app_0126.py').read_text('utf-8'))
publisher=publisher.replace('app-0127-transfer.zip','app-0127-final-transfer.zip').replace('0.10.27-inputs.json','0.10.27-final-inputs.json')
notes='15号手写笔：可开启逐点压感粗细，并选择主/副侧键按住临时整笔擦除，支持撤销；笔画中换键取消未完成动作。设置默认关闭，工具栏手写笔设置开启，仅使用系统实际笔输入。压感随保存、恢复、同步保留，旧笔迹不变。兼容服务已先更新；旧客户端需更新后编辑压感页。保留26曲库和回收站改进。'
start=publisher.index("'曲库直接选择个人");end=publisher.index("')",start)
publisher=publisher[:start]+repr(notes)+publisher[end+1:]
compile(publisher,'publish_app_0127.py','exec')
(w/'publish_app_0127.py').write_text(publisher,encoding='utf-8',newline='\n')
(stage/'publish-app-0127-final.py').write_bytes(publisher.encode('utf-8'))
test=adapt((w/'test_publish_app_0126.py').read_text('utf-8')).replace('Synthetic38','Synthetic39').replace('fixture38','fixture39')
(w/'test_publish_app_0127.py').write_text(test,encoding='utf-8',newline='\n')
verify=adapt((w/'verify_public_0126_direct.py').read_text('utf-8')).replace('0.10.27-inputs.json','0.10.27-final-inputs.json')
(w/'verify_public_0127_direct.py').write_text(verify,encoding='utf-8',newline='\n')
with zipfile.ZipFile(stage/'app-0127-final-transfer.zip','x',zipfile.ZIP_DEFLATED) as z:z.write(apk,'app.apk')
bundle=stage/'app-0127-final-transfer.zip'
expected=dict(versionCode=39,versionName='0.10.27',size=report['size'],sha256=report['sha256'],
    previousSha256='131466fb0b7ae08ce48be13311ebf896a99536afa58e254a01014ea7a94a2a26',
    bundleSize=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),
    serviceInputs=json.loads((stage/'0127-service-inputs.json').read_text('utf-8'))['serviceInputs'])
config=json.dumps(expected,indent=2).encode('utf-8');(stage/'0.10.27-final-inputs.json').write_bytes(config)
helper=(stage/'service-patch-0127.py').read_bytes();assert helper==(w/'service_patch_0127.py').read_bytes()
prefix=f"import pathlib,hashlib,json; root=pathlib.Path('/data/expanded-0122'); raw=pathlib.Path('/releases/service-patch-0127.py').read_bytes(); assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256(helper).hexdigest()!r}; config=pathlib.Path('/releases/0.10.27-final-inputs.json').read_bytes(); assert hashlib.sha256(config).hexdigest()=={hashlib.sha256(config).hexdigest()!r}; expected=json.loads(config); scope={{'__name__':'service_update'}}; exec(compile(raw,'service-patch-0127.py','exec'),scope); "
prepare=prefix+"scope['prepare'](root,expected)"
release=prefix+"proof=scope['after'](root,expected); "+f"raw=pathlib.Path('/releases/publish-app-0127-final.py').read_bytes(); assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256(publisher.encode('utf-8')).hexdigest()!r}; pub={{'__name__':'apk_update'}}; exec(compile(raw,'publish-app-0127-final.py','exec'),pub); result=pub['publish_bundle'](root,pathlib.Path('/releases/app-0127-final-transfer.zip'),expected); print('SERVICE_0127_DEPLOYED_AND_APP_PUBLISHED',json.dumps(dict(serviceUpdated=True,databaseMigrated=False,independentRestore=proof['independentRestore'],pdfs=len(proof['before']['pdfs']),sourceInputs=len(expected['serviceInputs']))),flush=True)"
common='''    user: "10001:10001"
    volumes:
      - team-data-0119:/data
      - /volume1/docker/yuepuruanjian-team-service/team-service/releases:/releases:ro
    read_only: true
    tmpfs:
      - /tmp:size=128m,mode=1777
    cap_drop: [ALL]
    security_opt: [no-new-privileges:true]
    mem_limit: 512m
'''
compose='''services:
  prepare:
    image: yuepu-team-api:0.10.27
    entrypoint: ["python", "-c"]
    command:
      - '''+json.dumps(prepare)+'\n'+common+'''    restart: "no"
  team-api:
    image: yuepu-team-api:0.10.27
    depends_on:
      prepare:
        condition: service_completed_successfully
    entrypoint: ["python", "/app/server.py", "--data", "/data/expanded-0122", "--expanded"]
    command: ["serve", "--host", "0.0.0.0", "--port", "8787", "--trusted-proxy", "172.30.87.1"]
    ports:
      - "127.0.0.1:8787:8787"
'''+common+'''    restart: unless-stopped
    healthcheck:
      test: ["CMD", "python", "-c", "import http.client; c=http.client.HTTPConnection('127.0.0.1',8787,timeout=3); c.request('GET','/v1/me'); assert c.getresponse().status==403"]
      interval: 15s
      timeout: 5s
      start_period: 15s
      retries: 4
  release-check:
    image: yuepu-team-api:0.10.27
    depends_on:
      team-api:
        condition: service_healthy
    entrypoint: ["python", "-c"]
    command:
      - '''+json.dumps(release)+'\n'+common+'''    restart: "no"
volumes:
  team-data-0119:
    external: true
    name: yuepu-team-api_team-data-0119
networks:
  default:
    external: true
    name: yuepu-team-api_default
'''
(stage/'compose-live-0127-final.yaml').write_bytes(compose.encode('utf-8'))
print('SERVICE_AND_APP_0127_RELEASE_PREPARED',bundle.stat().st_size,hashlib.sha256(config).hexdigest())
