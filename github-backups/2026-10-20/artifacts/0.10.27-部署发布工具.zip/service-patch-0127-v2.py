"""Compatible ink parser update. No schema migration, root switch or score operation."""
from pathlib import Path
from contextlib import closing
import hashlib,json,os,sqlite3,re
from app_release import AppReleases
from backup_archive import fingerprint
from expanded_permanent import open_active,create_archive,restore_archive,validate_archive

def save(path,value):
    with path.open('x',encoding='utf-8') as out:
        json.dump(value,out,ensure_ascii=False,indent=2);out.flush();os.fsync(out.fileno())

def image_check(expected,app=Path('/app')):
    for name,sha in expected['serviceInputs'].items():
        assert Path(name).name==name
        assert hashlib.sha256((app/name).read_bytes()).hexdigest()==sha,name
    from annotations import ink
    mark=dict(id='isolated-pressure-probe',kind='PEN',points=[[.2,.3],[.8,.7]],pressures=[.1,.9],color=0xff000000,width=.003,symbol='f')
    assert json.loads(ink([mark]))==[mark]
    for invalid in (dict(mark,pressures=[.2]),dict(mark,pressures=[True,.5]),dict(mark,kind='SYMBOL')):
        try:ink([invalid]);raise AssertionError('Invalid pressure accepted')
        except Exception as error:
            if isinstance(error,AssertionError):raise

def snapshot(root):
    ignored={'sessions','invitations','rate_limits','audit','operation_records','sqlite_sequence'}
    rows={}
    with closing(sqlite3.connect((root/'team.sqlite3').as_uri()+'?mode=ro',uri=True)) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        assert db.execute('PRAGMA user_version').fetchone()[0]==4
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
        metadata=dict(db.execute('SELECT key,value FROM metadata'))
        assert metadata['scoreNamingVersion']=='2'
        for table, in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
            assert re.fullmatch('[a-zA-Z0-9_]+',table)
            if table in ignored:continue
            records=[list(r) for r in db.execute('SELECT * FROM "'+table+'" ORDER BY rowid')]
            if table=='metadata':records=[r for r in records if r[0] not in {'numberingCandidateRoot','numberingCandidateId'}]
            if table=='permanent_deletion_jobs':
                columns=[row[1] for row in db.execute('PRAGMA table_info(permanent_deletion_jobs)')]
                index=columns.index('plan')
                for record in records:
                    plan=json.loads(record[index])
                    assert plan['storageId']==metadata['numberingCandidateId'],'Deletion plan storage binding mismatch'
                    plan['storageId']='<verified-own-storage>'
                    record[index]=json.dumps(plan,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
            raw=json.dumps(records,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False,default=lambda b:b.hex()).encode()
            rows[table]=dict(count=len(records),sha256=hashlib.sha256(raw).hexdigest())
        pdfs={aid:dict(size=size,sha256=sha) for aid,sha,size in db.execute('SELECT id,hash,size FROM artifacts ORDER BY id')}
    for aid,value in pdfs.items():assert fingerprint(root/'artifacts'/(aid+'.pdf'))==value
    return dict(tables=rows,pdfs=pdfs)

def prepare(root,expected,app=Path('/app')):
    image_check(expected,app)
    assert root.is_dir() and not root.is_symlink()
    service=open_active(root)
    release=AppReleases(root).current()
    assert release['versionCode'] in (38,39)
    assert release['sha256']==expected['previousSha256'] if release['versionCode']==38 else release['sha256']==expected['sha256']
    folder=root/'backups'/'before-service-0127-v2'
    for path in (folder.parent,folder):
        assert not path.is_symlink();path.mkdir(exist_ok=True)
    proof_path=folder/'verified.json'
    if proof_path.exists():
        proof=json.loads(proof_path.read_text('utf-8'))
        assert proof['root']==str(root.resolve()) and fingerprint(folder/'backup.zip')==proof['backup']
        print('SERVICE_0127_PREPARE_ALREADY_VERIFIED',str(proof_path),flush=True)
        return proof
    before=snapshot(root);backup=folder/'backup.zip'
    if not backup.exists():create_archive(service,backup)
    restored=folder/'independent-restore'
    if not restored.exists():restore_archive(backup,restored)
    assert snapshot(restored)==before,'Independent restore differs from pre-update business data'
    assert snapshot(root)==before,'Source changed during update backup'
    assert AppReleases(root).current()==release
    proof=dict(root=str(root.resolve()),backup=fingerprint(backup),independentRestore=True,before=before,
               previousRelease=release,databaseVersion=4,namingVersion=2,noMigration=True)
    save(proof_path,proof)
    print('SERVICE_0127_BACKUP_AND_INDEPENDENT_RESTORE_VERIFIED',len(before['pdfs']),str(proof_path),flush=True)
    return proof

def after(root,expected,app=Path('/app')):
    image_check(expected,app)
    folder=root/'backups'/'before-service-0127-v2'
    proof=json.loads((folder/'verified.json').read_text('utf-8'))
    assert proof['root']==str(root.resolve()) and proof['independentRestore'] and proof['noMigration']
    assert fingerprint(folder/'backup.zip')==proof['backup']
    assert snapshot(root)==proof['before'],'Business data changed during service update; stop APK publication and inspect'
    release=AppReleases(root).current()
    assert release['versionCode']==38 and release['sha256']==expected['previousSha256'] or release['versionCode']==39 and release['sha256']==expected['sha256']
    print('SERVICE_0127_LIVE_DATA_AND_IMAGE_VERIFIED',len(proof['before']['pdfs']),flush=True)
    return proof

if __name__=='__main__':
    import sys
    assert os.getuid()==10001
    expected=json.loads(Path('/releases/0.10.27-inputs.json').read_text('utf-8'))
    root=Path('/data/expanded-0122')
    if sys.argv[1]=='prepare':prepare(root,expected)
    elif sys.argv[1]=='after':after(root,expected)
    elif sys.argv[1]=='image':image_check(expected);print('SERVICE_0127_IMAGE_PREFLIGHT_VERIFIED',flush=True)
    else:raise AssertionError('Unknown update phase')
