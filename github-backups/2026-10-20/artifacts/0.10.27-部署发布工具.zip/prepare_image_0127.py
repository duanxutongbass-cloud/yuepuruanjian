from pathlib import Path
import json,hashlib,zipfile
w=Path(__file__).resolve().parent;stage=w/'0127-nas';stage.mkdir(exist_ok=True)
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service')
old=json.loads((w/'nas-0122/number13-release-inputs.json').read_text('utf-8'))['serviceInputs']
inputs={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in old}
assert {n for n,h in old.items() if inputs[n]!=h}=={'annotations.py'}
config=json.dumps(dict(serviceInputs=inputs),indent=2).encode('utf-8')
(stage/'0127-service-inputs.json').write_bytes(config)
helper=(w/'service_patch_0127.py').read_bytes();compile(helper,'service_patch_0127.py','exec')
(stage/'service-patch-0127.py').write_bytes(helper)
docker='FROM yuepu-team-api:0.10.22\nCOPY --chown=10001:10001 annotations.py /app/annotations.py\nCOPY --chown=10001:10001 Dockerfile.source /app/Dockerfile\n'
with zipfile.ZipFile(stage/'service-0127-patch.zip','x',zipfile.ZIP_DEFLATED) as z:
    z.writestr('service-0127-patch/Dockerfile',docker)
    z.write(r/'annotations.py','service-0127-patch/annotations.py')
    z.write(r/'Dockerfile','service-0127-patch/Dockerfile.source')
command=f"import pathlib,hashlib,json; p=pathlib.Path('/releases/service-patch-0127.py'); raw=p.read_bytes(); assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256(helper).hexdigest()!r}; config=pathlib.Path('/releases/0127-service-inputs.json').read_bytes(); assert hashlib.sha256(config).hexdigest()=={hashlib.sha256(config).hexdigest()!r}; scope={{'__name__':'image_preflight'}}; exec(compile(raw,str(p),'exec'),scope); scope['image_check'](json.loads(config)); print('SERVICE_0127_IMAGE_PREFLIGHT_VERIFIED',flush=True)"
compose='''services:
  image-check:
    build: /volume1/docker/yuepuruanjian-team-service/team-service/releases/service-0127-patch
    image: yuepu-team-api:0.10.27
    entrypoint: ["python", "-c"]
    command:
      - '''+json.dumps(command)+'''
    user: "10001:10001"
    volumes:
      - /volume1/docker/yuepuruanjian-team-service/team-service/releases:/releases:ro
    read_only: true
    tmpfs:
      - /tmp:size=64m,mode=1777
    cap_drop: [ALL]
    security_opt: [no-new-privileges:true]
    mem_limit: 128m
    restart: "no"
networks:
  default:
    external: true
    name: yuepu-team-api_default
'''
(stage/'compose-image-0127.yaml').write_bytes(compose.encode('utf-8'))
print('SERVICE_0127_IMAGE_PATCH_PREPARED',len(inputs),(stage/'service-0127-patch.zip').stat().st_size)
