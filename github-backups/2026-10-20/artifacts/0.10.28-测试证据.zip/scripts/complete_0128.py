from pathlib import Path
import datetime,hashlib,json,zipfile
w=Path(__file__).resolve().parent;o=w.parent/'outputs';repo=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((w/'0128-nas/0.10.28-inputs.json').read_text('utf-8'));raw=(w/'0128-nas-release-check.log').read_text('utf-8')
def marker(name):return json.JSONDecoder().raw_decode(raw.split(name,1)[1].lstrip())[0]
app=marker('APP_0128_PUBLISHED_AND_FULL_HTTPS_VERIFIED');service=marker('SERVICE_0128_DEPLOYED_AND_APP_PUBLISHED')
assert service==dict(serviceUpdated=True,databaseMigrated=False,independentRestore=True,pdfs=0,sourceInputs=26)
assert 'SERVICE_0128_LIVE_DATA_AND_IMAGE_VERIFIED 0' in raw
assert 'SERVICE_0128_BACKUP_AND_INDEPENDENT_RESTORE_VERIFIED 0' in (w/'0128-nas-prepare.log').read_text('utf-8')
assert 'SERVICE_0128_IMAGE_PREFLIGHT_VERIFIED' in (w/'0128-nas-image-preflight-dom.txt').read_text('utf-8')
live=(w/'0128-nas-live-dom.txt').read_text('utf-8');assert 'yuepu-team-api-0128-team-api-1' in live and '良好' in live and 'yuepu-team-api:0.10.28' in live
public=json.loads((o/'nas-0.10.28-public-verification.json').read_text('utf-8'));auth=json.loads((o/'nas-0.10.28-number-release-auth.json').read_text('utf-8'))
assert dict(app['release'],available=True)==public['metadata']
assert app['previousReleaseRetained'] and app['fullPublicDownload']==public['fullDownload']==dict(size=e['size'],sha256=e['sha256'])
assert len(public['anonymousPrivate'])==20 and all(v==401 for v in public['anonymousPrivate'].values())
assert len(auth)==3 and all(v['status']==401 for v in auth.values())
assert public['serviceChanged'] and not app['productionScoreOperations'] and not app['databaseMigrated']
tested=json.loads((w/'0128-full-inputs.json').read_text('utf-8'));sv=json.loads((w/'0128-service-full-inputs.json').read_text('utf-8'))
for n,h in tested.items():assert sha(repo/n)==h,n
for n,h in sv.items():assert sha(repo/'team-service'/n)==h,n
assert sha(o/'yuepuruanjian-0.10.28-number-release.apk')==e['sha256']
full=json.loads((w/'0128-full-summary.json').read_text('utf-8'));serviceTests=json.loads((w/'0128-service-full-summary.json').read_text('utf-8'))
proof=dict(app=app,service=service,publicProof='nas-0.10.28-public-verification.json',newPrivateAuthProof='nas-0.10.28-number-release-auth.json',serviceImage='yuepu-team-api:0.10.28',previousServiceImage='yuepu-team-api:0.10.27',productionRoot='/data/expanded-0122',businessProject='yuepu-team-api-0128',previousBusiness='yuepu-team-api-0127-final-team-api-1',previousBusinessStoppedObserved=True,previousBusinessObservation='Normal Stop followed by 已停止 and 启动 visible in NAS UI before new project completion',backup='/data/expanded-0122/backups/before-service-0128/backup.zip',backupProof='/data/expanded-0122/backups/before-service-0128/verified.json',databaseMigrated=False,productionScoreOperations=False,productionNumberReleasePerformed=False,registeredSourcePdfs=service['pdfs'],note='APK component serviceChanged=false describes channel-only operation; overall service27->28 updated first. Current NAS has zero registered PDFs; real deletion history and all business table fingerprints were verified, no historical PDF count substituted.')
(o/'nas-0.10.28-deployment-verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
status='2026-10-20 0.10.28（40）已发布既有NAS渠道：只释放用户所选、NAS已彻底删除整首曲目的编号，其他曲目/编号保持。管理员检查编号→多选→预览→勾选备份并释放；后台当次完整备份、无现存/回收站/待传占用、持久幂等及新旧曲目身份隔离。App767项/127类、服务258项/29文件通过，Lint0错22警告、327份App输入和原签名保持；失败日志/夹具和依赖修正保留。NAS新镜像26份源码预检、停旧27后完整备份/独立恢复、业务行和PDF哈希核验通过，同原根/data/expanded-0122、库4/命名2，无部署迁库。服务28健康后发布40，NAS与电脑独立标准TLS整包21370470字节、SHA6a9996c553d449fc452ddfa98942f69340b9030b8b26e33fb63f05b3714ccc66一致；旧39保留，旧27业务停止。20原私有和3新释放接口匿名401；未代用户释放任何生产编号/删除真实谱，当前NAS登记PDF0如实记录。待用户本人应用更新后验收；先发布再本人验收保持。多团队19后续、automation-2暂停，无分支/提交/代理。'
p=repo/'desktop-organizer/PROGRESS.md';s=p.read_text('utf-8');heading='# 开发进度（先读本页，再按需查历史）';assert s.startswith(heading);assert status not in s;p.write_text(s.replace(heading,heading+'\n\n'+status,1),encoding='utf-8')
p=repo/'docs/NUMBER_RELEASE_0128.md';s=p.read_text('utf-8');s=s.replace('\n\n','\n\n发布状态（2026-10-20）：0.10.28（40）已上线既有NAS更新渠道，服务28运行健康；当次完整备份、独立恢复和原业务数据核验通过，NAS及电脑标准TLS整包哈希一致，旧39包保留。767项App/258项服务通过，23个匿名私有请求401；真机由用户更新后本人验收。发布过程未执行真实编号释放。\n\n',1);s=s.replace('完整回归及实际发布状态以本Work最终报告为准，尚不宣称新版本已上线或本人真机验收。','完整App767项/127类与服务29文件258项均通过，APK/AndroidTest/Lint构建成功、Lint0错误22警告，327份App输入封存同签名。发布和标准TLS整包核验已完成；本人真机验收待用户更新后反馈。');p.write_text(s,encoding='utf-8')
for name in ('docs/README.md','docs/NUMBERED_DEVELOPMENT.md'):
 p=repo/name;s=p.read_text('utf-8');s=s.replace('\n\n','\n\n2026-10-20 当前已发布0.10.28（40）：新增仅释放NAS中已彻底删除整首曲目的所选编号，其余曲目保持原号，详见[编号释放](NUMBER_RELEASE_0128.md)。管理员多选预览/备份确认、新旧身份隔离；App767/服务258通过，先发布再由用户本人更新验收。下方旧版本状态保留为历史。\n\n',1);p.write_text(s,encoding='utf-8')
names=set(json.loads((o/'0.10.27-源码校验.json').read_text('utf-8')));names.update(tested);names.update('team-service/'+n for n in sv);names.add('docs/NUMBER_RELEASE_0128.md')
# Include current shared desktop additions without touching that product's implementation.
for base in ('desktop-organizer/src','desktop-organizer/tests','desktop-organizer/scripts'):
 for p in (repo/base).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'):names.add(p.relative_to(repo).as_posix())
for p in (repo/'desktop-organizer').iterdir():
 if p.is_file() and p.suffix.lower() in ('.md','.toml','.txt','.spec','.bat','.ps1','.json'):names.add(p.relative_to(repo).as_posix())
manifest={n:dict(bytes=(repo/n).stat().st_size,sha256=sha(repo/n)) for n in sorted(names)}
with zipfile.ZipFile(o/'0.10.28-完整源码.zip','x',zipfile.ZIP_DEFLATED) as z:
 for n in sorted(names):z.write(repo/n,'yuepuruanjian/'+n)
 z.writestr('SOURCE-SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(o/'0.10.28-完整源码.zip') as z:
 assert z.testzip() is None
 for n,v in manifest.items():assert hashlib.sha256(z.read('yuepuruanjian/'+n)).hexdigest()==v['sha256'],n
(o/'0.10.28-源码校验.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
report=dict(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),android='0.10.28 (40)',full=full,serviceFull=serviceTests,sourceInputs=len(tested),sourceArchiveFiles=len(manifest),nasPublished=True,previousApp39Retained=True,serviceUpdated=True,databaseMigrated=False,roomVersion=6,databaseVersion=4,namingVersion=2,productionScoreOperations=False,productionNumberReleasePerformed=False,physicalAcceptance='pending user after published update',workflow='Develop/local validation -> publish NAS and verify -> user personally updates/tests -> repair and republish',multipleTeams='deferred roadmap19',automation2='paused',registeredSourcePdfs=service['pdfs'],publicationProof='nas-0.10.28-deployment-verification.json',publicProof='nas-0.10.28-public-verification.json',limits=['No physical device operation/acceptance by Codex','Release does not clear PC organizer history','Current full backup required for restore activation after number reuse; old snapshots missing current release ledger/reused files refused'],failuresRetained=['Service initial missing rapidfuzz dependency: whole partition1 and exact part0 case passed after environment fix','First Android full run missing TEAM_SERVICE_TEST_PYTHON: 740 passed/27 fixture startup failures; rerun all767 passed','Second full command PowerShell split Gradle -P option: no tests; quoted parameters and full run passed','Related first run 40 passed/2 fixture issues: substring match and actual retired Room cleanup flow; all42 plus extra VM test passed','Earlier service synthetic fixtures/duplicate collection retained; final10 new tests passed','Initial synthetic UI screenshot captured activity behind dialog; changed capture to actual Dialog and visually checked final image'])
(o/'0.10.28-完成验证.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(o/'0.10.28-交付与验收说明.txt').write_text('''曲谱库0.10.28（40）已发布：NAS已彻底删除曲目的编号释放

在“我的→应用更新”升级到0.10.28，使用管理员账号进入“曲库管理→检查编号／补空号”。多选可释放编号→预览释放所选编号→勾选确认→备份并释放。仅整首曲目已彻底删除、没有任何现存/回收站/有效待传占用时才列入候选，每次最多200个。回收站删除不会自动释放编号，仍存在的曲目及其编号不变。释放后新曲优先补最小空号；例如释放001、保留003，新曲可用001，003不改号。电脑整理器的原库和编号不会被此操作清空。

每次真实释放先做完整NAS备份并验证，再重验当前登录、权限、目录修订与选定范围；失败保留原状态并可重试。原删除台账及旧分谱ID屏障保留，同号新曲使用新身份，不继承旧缓存、批注、收藏和文件夹引用。出现复用曲目后，旧阅读端会要求更新；其他平板也应更新。新曲再次彻底删除后需再次明确释放。旧备份若缺少当前释放台账或同号新谱，恢复激活会拒绝；应使用当前完整备份，避免按旧号误删新曲。

请由你本人更新后验收：候选是否只包含已彻底删除整首曲目；只选目标编号释放后其他曲目保持；再次检查可用空号，再新建曲目核对。Codex没有代你执行任何真实编号释放或真实曲谱删除，也未代操作平板。

自动验证：完整App767项/127类、服务端29文件258项通过，0失败/错误/跳过；App相关42项及额外ViewModel身份/提交/刷新验证、服务新增10项、真实合成备份/独立恢复/编号复用/HTTP发布/幂等/篡改拒绝通过（相关项包含在完整全集内，不重复相加）。APK、AndroidTest APK、Lint成功，Lint0错误22警告，327份App输入和原签名保持，Room6、服务库4/命名2。最初缺环境依赖、夹具及命令失败均原样保留，不跳测试。

NAS新镜像26文件SHA预检通过，正常停旧27业务后当次完整备份并独立恢复、比对原业务行和PDF哈希；同数据根/data/expanded-0122、数据卷/网络/端口/权限启动服务28，健康且业务检查通过后才发布App40，旧39包和旧27镜像/停止容器保留。NAS与电脑独立标准TLS完整APK一致，21370470字节，SHA256 6a9996c553d449fc452ddfa98942f69340b9030b8b26e33fb63f05b3714ccc66；20原私有+3新释放接口均匿名401。当次NAS登记PDF数为0，原业务表和删除历史如实核验，未拿历史PDF数量冒充。部署时无迁库或生产编号释放；两张可选释放表只在管理员首次实际确认时事务创建。

完整源码包含当前Android/服务/共享Windows源码和真实测试，保留当前桌面0.1.5的新文件；本轮没有修改桌面生产实现或重建其EXE，既有Windows验证不冒充本次新测。AndroidTest APK已编译封存，真机验收仍由你本人完成。发布前验证报告nasPublished=false是历史快照，当前状态以完成验证、NAS报告和截图为准。
''',encoding='utf-8')
seen=set()
with zipfile.ZipFile(o/'0.10.28-测试证据.zip','x',zipfile.ZIP_DEFLATED) as z:
 for pattern in ('0128-*.log','0128-*.xml','0128-*.json','0128-*signature.txt','0128-*-dom.txt'):
  for p in sorted(w.glob(pattern)):
   if p.name not in seen:z.write(p,p.name);seen.add(p.name)
 for folder in sorted(w.glob('0128-*-results')):
  for p in sorted(folder.rglob('TEST-*.xml')):z.write(p,p.relative_to(w).as_posix())
 for pattern in ('freeze_0128.py','seal_0128.py','prepare_*0128.py','test_*0128*.py','verify_*0128*.py','complete_0128.py'):
  for p in sorted(w.glob(pattern)):
   if p.name not in seen:z.write(p,'scripts/'+p.name);seen.add(p.name)
 z.write(o/'0.10.28-编号释放界面.png','ui/0128-number-release.png');z.write(repo/'docs/NUMBER_RELEASE_0128.md','NUMBER_RELEASE_0128.md')
with zipfile.ZipFile(o/'0.10.28-部署发布工具.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((w/'0128-nas').rglob('*')):
  if p.is_file() and p.name not in ('app-0128-transfer.zip','service-0128-patch.zip'):z.write(p,p.relative_to(w/'0128-nas').as_posix())
 for n in ('service_patch_0128.py','publish_app_0128.py','test_deployment_0128.py','verify_public_0128_direct.py','verify_auth_0128.py','prepare_tools_0128.py','prepare_release_0128.py'):z.write(w/n,n)
with zipfile.ZipFile(o/'0.10.28-NAS上线证据.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(w.glob('0128-nas-*.txt')):z.write(p,p.name)
 for p in sorted(w.glob('0128-nas-*.log')):z.write(p,p.name)
 for p in sorted(o.glob('nas-0.10.28-*.json')):z.write(p,p.name)
 z.write(o/'nas-0.10.28-live.png','nas-0.10.28-live.png')
for p in o.glob('0.10.28-*.zip'):
 with zipfile.ZipFile(p) as z:assert z.testzip() is None,p
deliver=[p for p in o.iterdir() if '0.10.28' in p.name and p.is_file()]
checks={p.name:dict(size=p.stat().st_size,sha256=sha(p)) for p in sorted(deliver)}
(o/'0.10.28-交付SHA256.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print('APP_0128_PUBLISHED_AND_DELIVERED',len(manifest),len(tested),full,serviceTests,checks['yuepuruanjian-0.10.28-number-release.apk'])
