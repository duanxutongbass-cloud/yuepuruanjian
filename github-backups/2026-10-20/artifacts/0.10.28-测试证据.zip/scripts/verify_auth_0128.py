from pathlib import Path
import http.client,json
checks={}
for method,path in [('GET','/v2/admin/number-releases'),('POST','/v2/admin/number-releases/preview'),('POST','/v2/admin/number-releases/commit')]:
 c=http.client.HTTPSConnection('124355.xyz',18443,timeout=20)
 try:
  c.request(method,path,body=b'{}' if method=='POST' else None,headers={'Content-Type':'application/json'} if method=='POST' else {})
  response=c.getresponse();body=json.loads(response.read());assert response.status==401,(path,response.status,body)
  checks[method+' '+path]=dict(status=response.status,error=body['error'])
 finally:c.close()
Path(__file__).resolve().parents[1].joinpath('outputs/nas-0.10.28-number-release-auth.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print('NUMBER_RELEASE_0128_THREE_UNAUTHENTICATED_REQUESTS_REJECTED',checks)
