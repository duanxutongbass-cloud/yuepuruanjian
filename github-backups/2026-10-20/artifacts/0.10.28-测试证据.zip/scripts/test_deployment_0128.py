from pathlib import Path
import sys,importlib.util,json,zipfile,threading,hashlib
w=Path(__file__).resolve().parent
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service');sys.path.insert(0,str(r))
import test_expanded_permanent as fixture
from app_release import AppReleases
from expanded_permanent import ExpandedReadyApplication
from waitress import create_server
def module(name,file):
    spec=importlib.util.spec_from_file_location(name,w/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('helper0128','service_patch_0128.py');publisher=module('pub0128','publish_app_0128.py')
f=fixture.ExpandedPermanentTest();f.setUp()
try:
    f.delete(f.seed.artifact)
    view=f.app.number_releases.view(f.admin['token'],f.device)
    preview=f.app.number_releases.preview(dict(sequences=['001'],expectedRevision=view['revision']),f.admin['token'],f.device)
    import uuid
    f.app.number_releases.commit(dict(sequences=['001'],expectedRevision=view['revision'],scopeDigest=preview['scopeDigest'],
        requestId=str(uuid.uuid4()),confirmed=True),f.admin['token'],f.device)
    new,_=f.staged('0101001',title='Synthetic redeployed reused score');f.publish([new])
    previous=w/'synthetic-deployment-0128-previous.apk';current=w/'synthetic-deployment-0128-current.apk'
    for p,data in ((previous,b'Synthetic39'),(current,b'Synthetic40')):
        with zipfile.ZipFile(p,'x') as z:z.writestr('AndroidManifest.xml',data);z.writestr('classes.dex',b'Not installable synthetic validation')
    old=AppReleases(f.target).publish(previous,39,'0.10.27','Synthetic previous update')
    inputs=json.loads((w/'0128-nas/0128-service-inputs.json').read_text('utf-8'))['serviceInputs']
    expected=dict(publisher.fingerprint(current),versionCode=40,versionName='0.10.28',previousSha256=old['sha256'],serviceInputs=inputs)
    proof=helper.prepare(f.target,expected,r)
    assert helper.prepare(f.target,expected,r)==proof and helper.after(f.target,expected,r)==proof
    assert proof['independentRestore'] and len(proof['before']['pdfs'])==1
    before=helper.snapshot(f.target)
    bundle=w/'synthetic-deployment-0128-transfer.zip'
    with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:z.write(current,'app.apk')
    expected.update(bundleSize=bundle.stat().st_size,bundleSha256=publisher.fingerprint(bundle)['sha256'])
    server=create_server(ExpandedReadyApplication(f.service,allow_loopback_http=True),host='127.0.0.1',port=0,threads=2)
    worker=threading.Thread(target=server.run,daemon=True);worker.start()
    try:
        options=dict(origin=f'http://127.0.0.1:{server.effective_port}',allow_test_http=True)
        receipt=publisher.publish_bundle(f.target,bundle,expected,**options)
        assert publisher.publish_bundle(f.target,bundle,expected,**options)==receipt
        try:publisher.publish_bundle(f.target,bundle,dict(expected,bundleSha256='0'*64),**options);raise RuntimeError('Tampered APK bundle accepted')
        except AssertionError:pass
        assert AppReleases(f.target).current()==receipt['release'] and helper.snapshot(f.target)==before
        assert (f.target/'artifacts'/(new+'.pdf')).read_bytes()==f.pdf
        print('SERVICE_AND_APP_0128_ISOLATED_RELEASE_LEDGER_BACKUP_INDEPENDENT_RESTORE_HTTP_PUBLICATION_RETRY_TAMPER_VERIFIED')
    finally:server.task_dispatcher.shutdown();server.close();worker.join(5)
finally:f.doCleanups()
