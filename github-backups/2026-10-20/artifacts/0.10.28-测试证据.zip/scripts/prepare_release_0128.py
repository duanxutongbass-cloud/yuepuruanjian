from pathlib import Path
import json,hashlib,zipfile
w=Path(__file__).resolve().parent;out=w.parent/'outputs';stage=w/'0128-nas'
report=json.loads((out/'0.10.28-验证报告.json').read_text('utf-8'));assert report['tests']==767 and report['serviceFull']['tests']==258
apk=out/'yuepuruanjian-0.10.28-number-release.apk';assert hashlib.sha256(apk.read_bytes()).hexdigest()==report['sha256']
publisher=(w/'publish_app_0128.py').read_text('utf-8');assert (stage/'publish-app-0128.py').read_bytes()==publisher.encode('utf-8')
old=(w/'prepare_release_0127.py').read_text('utf-8');body=old[old.index('with zipfile.ZipFile'):]
body=body.replace('0.10.27','0.10.28').replace('0127','0128').replace('versionCode=39','versionCode=40').replace('131466fb0b7ae08ce48be13311ebf896a99536afa58e254a01014ea7a94a2a26','6b0506bf7926c72a90ed5a32d9891fa3a47766cd152e4ebb982594cdd09dcd49')
exec(compile(body,'prepare_release_0128_body','exec'))
verify=(w/'verify_public_0127_direct.py').read_text('utf-8').replace('0127','0128').replace('0.10.27','0.10.28').replace('versionCode\']==39','versionCode\']==40').replace('serviceChanged=False','serviceChanged=True')
(w/'verify_public_0128_direct.py').write_text(verify,encoding='utf-8')
