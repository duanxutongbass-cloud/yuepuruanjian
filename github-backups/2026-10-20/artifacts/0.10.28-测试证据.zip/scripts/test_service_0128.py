from pathlib import Path
import concurrent.futures,subprocess,sys,json,hashlib,xml.etree.ElementTree as ET,os
w=Path(__file__).resolve().parent
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service')
paths=sorted(r.glob('test_*.py'));assert len(paths)==29
inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*.py')}
(w/'0128-service-full-inputs.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
def run(index):
    names=[p.name for p in paths[index::2]]
    with (w/f'0128-service-full-{index}.log').open('w',encoding='utf-8') as output:
        result=subprocess.run([sys.executable,'-u','-m','pytest','-q',*names,'--junitxml='+str(w/f'0128-service-full-{index}.xml'),
                               '-p','no:cacheprovider'],cwd=r,stdout=output,stderr=subprocess.STDOUT)
    return index,result.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,range(2)))
assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in inputs.items())
summary=dict(tests=0,failures=0,errors=0,skipped=0)
for index,_ in results:
    root=ET.parse(w/f'0128-service-full-{index}.xml').getroot()
    for suite in root.iter('testsuite'):
        for key in summary:summary[key]+=int(suite.attrib.get(key,0))
(w/'0128-service-full-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
assert all(code==0 for _,code in results) and summary['tests']>=258 and summary['failures']==summary['errors']==summary['skipped']==0,(results,summary)
print('SERVICE_0128_FULL_PARTITIONED_VERIFIED',json.dumps(summary),flush=True)
