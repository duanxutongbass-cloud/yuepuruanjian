from pathlib import Path
import ast,hashlib,json,re,zipfile
w=Path(__file__).resolve().parent;stage=w/'0128-nas';stage.mkdir(exist_ok=True)
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service')
old=json.loads((w/'0127-nas/0.10.27-final-inputs.json').read_text('utf-8'))['serviceInputs']
names=set(old)|{'number_release.py'}
inputs={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(names)}
changed=sorted(n for n in names if n not in old or inputs[n]!=old[n])
assert inputs['requirements.txt']==old['requirements.txt'] and len(inputs)==26
config=json.dumps(dict(serviceInputs=inputs),indent=2).encode('utf-8');(stage/'0128-service-inputs.json').write_bytes(config)
def adapt(text):
    text=text.replace('0.10.27','0.10.28').replace('0127','0128')
    return re.sub(r'\b(38|39)\b',lambda m:{'38':'39','39':'40'}[m[0]],text)
helper=adapt((w/'service_patch_0127_v2.py').read_text('utf-8')).replace('before-service-0128-v2','before-service-0128')
needle="    from annotations import ink\n"
assert needle in helper
helper=helper.replace(needle,"    from number_release import sequence\n    from expanded_protocol import numbering_route\n    assert sequence('001')=='001' and sequence('9223372036854775807')=='9223372036854775807'\n    assert numbering_route('/v1/admin/number-releases/preview')\n"+needle)
compile(helper,'service_patch_0128.py','exec');(w/'service_patch_0128.py').write_text(helper,encoding='utf-8',newline='\n')
(stage/'service-patch-0128.py').write_bytes(helper.encode())
helper_sha=hashlib.sha256(helper.encode()).hexdigest()
docker='FROM yuepu-team-api:0.10.27\n'
for name in changed:
    if name!='Dockerfile':docker+=f'COPY --chown=10001:10001 {name} /app/{name}\n'
docker+='COPY --chown=10001:10001 Dockerfile.source /app/Dockerfile\n'
context=stage/'service-0128-patch';context.mkdir(exist_ok=True)
(context/'Dockerfile').write_text(docker,encoding='utf-8',newline='\n')
for n in changed:
    (context/('Dockerfile.source' if n=='Dockerfile' else n)).write_bytes((r/n).read_bytes())
with zipfile.ZipFile(stage/'service-0128-patch.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(context.iterdir()):z.write(p,'service-0128-patch/'+p.name)
command=f"import pathlib,hashlib,json; raw=pathlib.Path('/releases/service-patch-0128.py').read_bytes(); assert hashlib.sha256(raw).hexdigest()=={helper_sha!r}; config=pathlib.Path('/releases/0128-service-inputs.json').read_bytes(); assert hashlib.sha256(config).hexdigest()=={hashlib.sha256(config).hexdigest()!r}; scope={{'__name__':'image_preflight'}}; exec(compile(raw,'service-patch-0128.py','exec'),scope); scope['image_check'](json.loads(config)); print('SERVICE_0128_IMAGE_PREFLIGHT_VERIFIED',flush=True)"
compose='''services:
  image-check:
    build: /volume1/docker/yuepuruanjian-team-service/team-service/releases/service-0128-patch
    image: yuepu-team-api:0.10.28
    entrypoint: ["python", "-c"]
    command:
      - '''+json.dumps(command)+'''
    user: "10001:10001"
    volumes:
      - /volume1/docker/yuepuruanjian-team-service/team-service/releases:/releases:ro
    read_only: true
    tmpfs:
      - /tmp:size=64m,mode=1777
    cap_drop: [ALL]
    security_opt: [no-new-privileges:true]
    mem_limit: 128m
    restart: "no"
networks:
  default:
    external: true
    name: yuepu-team-api_default
'''
(stage/'compose-image-0128.yaml').write_bytes(compose.encode())
publisher=adapt((w/'0127-nas/publish-app-0127-final.py').read_text('utf-8'))
publisher=publisher.replace('app-0128-final-transfer.zip','app-0128-transfer.zip').replace('0.10.28-final-inputs.json','0.10.28-inputs.json')
tree=ast.parse(publisher)
old_note=next(n.args[3].value for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='publish' and len(n.args)==4)
note='新增已彻底删除曲目的编号释放：管理员在曲库管理→检查编号／补空号中多选、预览并勾选备份后释放。仅整曲彻底删除且无现存/回收站/待传占用时可释放，其他曲目保持原号，新曲优先补空号。保留删除台账和旧分谱ID屏障，同号新曲身份与旧缓存/批注隔离；出现复用曲目后旧阅读端需更新。保留27手写笔与26曲库/回收站改进。'
publisher=publisher.replace(repr(old_note),repr(note));compile(publisher,'publish_app_0128.py','exec')
(w/'publish_app_0128.py').write_text(publisher,encoding='utf-8',newline='\n');(stage/'publish-app-0128.py').write_bytes(publisher.encode())
(w/'0128-service-image-inputs.json').write_text(json.dumps(dict(inputs=inputs,changed=changed,helperSha256=helper_sha),indent=2),encoding='utf-8')
print('SERVICE_0128_IMAGE_INPUTS_PREPARED',len(inputs),changed,helper_sha)
