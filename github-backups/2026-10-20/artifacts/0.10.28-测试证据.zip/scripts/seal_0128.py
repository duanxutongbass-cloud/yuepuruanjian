from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as E
w=Path(__file__).resolve().parent;o=w.parent/'outputs';r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((w/'0128-full-inputs.json').read_text('utf-8'))
for n,h in inputs.items():assert sha(r/n)==h,n
assert 'BUILD SUCCESSFUL' in (w/'0128-full-third.log').read_text('utf-8')
results=list((r/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'))
s=dict(tests=0,classes=len(results),failures=0,errors=0,skipped=0)
saved=w/'0128-full-third-results';saved.mkdir(exist_ok=True)
for p in results:
 root=E.parse(p).getroot()
 for k in ('tests','failures','errors','skipped'):s[k]+=int(root.attrib[k])
 shutil.copy2(p,saved/p.name)
assert s['tests']==767 and s['classes']==127 and s['failures']==s['errors']==s['skipped']==0,s
lint=E.parse(r/'app/build/reports/lint-results-debug.xml').getroot()
s.update(lintErrors=sum(i.attrib['severity']=='Error' for i in lint),lintWarnings=sum(i.attrib['severity']=='Warning' for i in lint));assert not s['lintErrors']
shutil.copy2(r/'app/build/reports/lint-results-debug.xml',w/'0128-full-third-lint.xml')
metadata=json.loads((r/'app/build/outputs/apk/debug/output-metadata.json').read_text('utf-8'))['elements'][0];assert metadata['versionCode']==40 and metadata['versionName']=='0.10.28'
cert='9f360690612dabcdc4c13c8fb0b89af99402a64782f8fdcba79cddfb2be745fa'
signature=(w/'0128-final-signature.txt').read_text('utf-8');assert 'Verifies' in signature and cert in signature
service=json.loads((w/'0128-service-full-summary.json').read_text('utf-8'));assert service['tests']==258 and not service['failures']
for n,h in json.loads((w/'0128-service-full-inputs.json').read_text('utf-8')).items():assert sha(r/'team-service'/n)==h,n
apk=o/'yuepuruanjian-0.10.28-number-release.apk';shutil.copy2(r/'app/build/outputs/apk/debug/app-debug.apk',apk)
shutil.copy2(r/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk',o/'yuepuruanjian-0.10.28-androidTest.apk')
shutil.copy2(r/'app/build/reports/screenshots/0128-number-release.png',o/'0.10.28-编号释放界面.png')
report=dict(versionName='0.10.28',versionCode=40,size=apk.stat().st_size,sha256=sha(apk),**s,certificateSha256=cert,sameSignature=True,appInputs=inputs,serviceFull=service,serviceInputs=json.loads((w/'0128-nas/0128-service-inputs.json').read_text('utf-8'))['serviceInputs'],roomVersion=6,databaseVersion=4,namingVersion=2,schemasUnchanged=True,nasPublished=False,physicalAcceptance='pending user after publication',scope='Only selected NAS whole-piece permanently deleted numbers; all other pieces and numbers retained; backup and explicit administrator consent; generation isolation',relatedTests=43,numberReleaseServiceTests=10,isolatedDeploymentPassed=True,originalFailuresRetained=True,productionNumberReleasePerformed=False)
(o/'0.10.28-验证报告.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');(w/'0128-full-summary.json').write_text(json.dumps(s,indent=2),encoding='utf-8')
print('APP_0128_SEALED',json.dumps({k:report[k] for k in ('tests','classes','size','sha256','lintErrors','lintWarnings')}))
