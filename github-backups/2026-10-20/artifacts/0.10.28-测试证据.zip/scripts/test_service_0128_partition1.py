from pathlib import Path
import subprocess,sys,hashlib,json
w=Path(__file__).resolve().parent
r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service')
frozen=json.loads((w/'0128-service-full-inputs.json').read_text('utf-8'))
for n,h in frozen.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
paths=sorted(r.glob('test_*.py'));assert len(paths)==29
names=[p.name for p in paths[1::2]]
with (w/'0128-service-full-1-retest.log').open('w',encoding='utf-8') as output:
    result=subprocess.run([sys.executable,'-u','-m','pytest','-q',*names,'--junitxml='+str(w/'0128-service-full-1-retest.xml'),
                           '-p','no:cacheprovider'],cwd=r,stdout=output,stderr=subprocess.STDOUT)
for n,h in frozen.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
print('SERVICE_0128_PARTITION1_RETEST',result.returncode,len(names));sys.exit(result.returncode)
