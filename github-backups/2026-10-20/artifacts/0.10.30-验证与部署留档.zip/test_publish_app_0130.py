"""Isolated real APK channel update; never connects to production."""
from pathlib import Path
import sys,importlib.util,json,threading,hashlib
w=Path(__file__).resolve().parent;r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian/team-service');sys.path.insert(0,str(r))
from test_expanded_permanent import ExpandedPermanentTest
from app_release import AppReleases
from multiteam import MultiTeamDirectory,MultiTeamApplication
from waitress import create_server
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,w/file);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
helper=load('migration0129','service_patch_0129.py');old=load('oldpublisher','publish_app_0129.py');new=load('publisher0130','publish_app_0130.py')
e29=json.loads((w/'0129-nas/0.10.29-inputs.json').read_text('utf-8'));e30=json.loads((w/'0130-nas/0.10.30-inputs.json').read_text('utf-8'))
fixture=ExpandedPermanentTest();fixture.setUp()
try:
 AppReleases(fixture.target).publish(w.parent/'outputs/yuepuruanjian-0.10.28-number-release.apk',40,'0.10.28','Synthetic fixture')
 destination=fixture.root/'multi';helper.prepare(fixture.target,destination,e29,r);helper.retire(fixture.target,destination,e29,r)
 directory=MultiTeamDirectory(destination);server=create_server(MultiTeamApplication(directory,True),host='127.0.0.1',port=0,threads=4)
 worker=threading.Thread(target=server.run,daemon=True);worker.start()
 try:
  origin=f'http://127.0.0.1:{server.effective_port}'
  old.publish_bundle(destination,w/'0129-nas/app-0129-transfer.zip',e29,origin=origin,allow_test_http=True)
  primary=destination/'teams'/directory.marker['primary']
  before=helper.snapshot(__import__('expanded_permanent').open_active(primary))
  identity=helper.accounts(destination/'identity/team.sqlite3')
  kwargs=dict(origin=origin,allow_test_http=True)
  receipt=new.publish_bundle(destination,w/'0130-nas/app-0130-transfer.zip',e30,**kwargs)
  assert new.publish_bundle(destination,w/'0130-nas/app-0130-transfer.zip',e30,**kwargs)==receipt
  for wrong in (dict(e30,bundleSha256='0'*64),dict(e30,sha256='0'*64),dict(e30,previousSha256='0'*64)):
   try:new.publish_bundle(destination,w/'0130-nas/app-0130-transfer.zip',wrong,**kwargs);raise RuntimeError('Tampered inputs accepted')
   except AssertionError:pass
  assert helper.accounts(destination/'identity/team.sqlite3')==identity
  assert helper.snapshot(__import__('expanded_permanent').open_active(primary))==before
  assert helper.fingerprint(destination/'app-releases'/(e29['sha256']+'.apk'))==dict(size=e29['size'],sha256=e29['sha256'])
  report=dict(isolated=True,normalLocalhostHttp=True,realOldAndNewApks=True,oldReleaseRetained=True,repeatPublishIdempotent=True,
   bundleApkAndPreviousTamperRejected=True,businessAndIdentityUnchanged=True,versionCode=42,sha256=e30['sha256'],productionTouched=False)
  (w/'0130-publication-isolated-verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
  print('APP_0130_ISOLATED_REAL_APK_UPDATE_RETRY_TAMPER_AND_BUSINESS_PRESERVATION_PASS',flush=True)
 finally:server.task_dispatcher.shutdown();server.close();worker.join(10)
finally:fixture.doCleanups()
