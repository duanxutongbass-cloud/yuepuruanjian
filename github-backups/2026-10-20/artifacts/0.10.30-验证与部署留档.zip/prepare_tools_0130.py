from pathlib import Path
import hashlib,json,zipfile
w=Path(__file__).resolve().parent;r=Path('C:/Users/dxt/Documents/Codex/2026-10-14/xian/outputs/yuepuruanjian')
app=json.loads((w/'0130-app-full-summary.json').read_text('utf-8'))
assert app['tests']==dict(tests=785,failures=0,errors=0,skipped=0) and app['inputsUnchanged'] and app['existingCertificatePreserved']
inputs=json.loads((w/'0129-nas/0.10.29-inputs.json').read_text('utf-8'))['serviceInputs']
assert len(inputs)==30 and all(hashlib.sha256((r/'team-service'/n).read_bytes()).hexdigest()==sha for n,sha in inputs.items())
stage=w/'0130-nas';stage.mkdir(exist_ok=True)
apk=w.parent/'outputs/yuepuruanjian-0.10.30-release.apk';raw=apk.read_bytes()
assert hashlib.sha256(raw).hexdigest()==app[apk.name]['sha256']
bundle=stage/'app-0130-transfer.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:z.write(apk,'app.apk')
expected=dict(versionCode=42,versionName='0.10.30',size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
 previousSha256='280d2e865fd3dfb1b540387819166e555b4b87a0d9452541a84ba3c1740a9eb0',serviceInputs=inputs,
 bundleSize=bundle.stat().st_size,bundleSha256=hashlib.sha256(bundle.read_bytes()).hexdigest())
config=json.dumps(expected,indent=2).encode();(stage/'0.10.30-inputs.json').write_bytes(config)
publisher=(w/'publish_app_0130.py').read_bytes();compile(publisher,'publish-app-0130.py','exec');(stage/'publish-app-0130.py').write_bytes(publisher)
cmd="import pathlib,hashlib,json,os; os.umask(0o077); assert os.getuid()==10001; "
cmd+=f"raw=pathlib.Path('/releases/0.10.30-inputs.json').read_bytes(); assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256(config).hexdigest()!r}; expected=json.loads(raw); "
cmd+="assert len(expected['serviceInputs'])==30; assert all(pathlib.Path(n).name==n and hashlib.sha256((pathlib.Path('/app')/n).read_bytes()).hexdigest()==h for n,h in expected['serviceInputs'].items()); "
cmd+=f"raw=pathlib.Path('/releases/publish-app-0130.py').read_bytes(); assert hashlib.sha256(raw).hexdigest()=={hashlib.sha256(publisher).hexdigest()!r}; scope={{'__name__':'apk_only_update'}}; exec(compile(raw,'publish-app-0130.py','exec'),scope); "
cmd+="scope['publish_bundle'](pathlib.Path('/data/multiteam-0129'),pathlib.Path('/releases/app-0130-transfer.zip'),expected); print('APP_0130_ONLY_CHANNEL_UPDATE_VERIFIED_SERVICE_UNCHANGED',flush=True)"
compose='''services:
  publish-apk:
    image: yuepu-team-api:0.10.29
    entrypoint: ["python", "-c"]
    command:
      - '''+json.dumps(cmd)+'''
    user: "10001:10001"
    volumes:
      - team-data-0119:/data
      - /volume1/docker/yuepuruanjian-team-service/team-service/releases:/releases:ro
    read_only: true
    tmpfs:
      - /tmp:size=128m,mode=1777
    cap_drop: [ALL]
    security_opt: [no-new-privileges:true]
    mem_limit: 512m
    restart: "no"
volumes:
  team-data-0119:
    external: true
    name: yuepu-team-api_team-data-0119
networks:
  default:
    external: true
    name: yuepu-team-api_default
'''
(stage/'compose-app-0130.yaml').write_text(compose,encoding='utf-8',newline='\n')
(w/'0130-deployment-inputs.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.iterdir() if p.is_file()},indent=2),encoding='utf-8')
print('APP_0130_APK_ONLY_DEPLOYMENT_PREPARED',expected['sha256'])
