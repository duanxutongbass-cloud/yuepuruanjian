param([ValidateSet('focused','reading','full')][string]$Phase='focused')
$env:JAVA_HOME='C:\Users\dxt\Documents\Codex\developer-tools\java\jdk-21.0.12.1'
$env:GRADLE_USER_HOME='C:\Users\dxt\Documents\Codex\developer-tools\gradle-cache'
$env:ANDROID_USER_HOME='C:\Users\dxt\Documents\Codex\developer-tools\android-user'
$env:ANDROID_HOME='C:\Users\dxt\Documents\Codex\developer-tools\android-sdk'
$env:TEAM_SERVICE_TEST_PYTHON='C:\Users\dxt\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$env:PYTHONPATH='C:\Users\dxt\Documents\Codex\2026-10-18\yuepu-number13\work\0129-desktop-deps;C:\Users\dxt\Documents\Codex\2026-10-18\yuepu-number13\work\service-test-deps'
$env:SCORE_ORGANIZER_DATA_DIR='C:\Users\dxt\Documents\Codex\2026-10-18\yuepu-number13\work\0130-test-config\data'
$env:SCORE_ORGANIZER_EXPANDED_PROFILE='C:\Users\dxt\Documents\Codex\2026-10-18\yuepu-number13\work\0130-test-config\profile'
$env:PYTHONIOENCODING='utf-8'
$taskArgs=@('--no-daemon','--offline',':app:testDebugUnitTest')
if($Phase -eq 'focused') {
    foreach($test in @('account.SignupFeedbackUiTest','account.MembershipViewModelTest','account.MembershipUiTest','account.AccountTeamsUiTest','account.AccountTeamsTest','personal.AccountLibrarySpacesTest','personal.PersonalProfileEntryTest','ui.CompactProfileLayoutTest')) {
        $taskArgs+=@('--tests',('com.ensemble.scorelibrary.'+$test))
    }
} elseif($Phase -eq 'reading') {
    foreach($test in @('pdf.NativeReadingTest','pdf.PdfReaderViewModelTest','pdf.ConcertReaderTest','pdf.ReaderLayoutTest','ui.ScorePreviewViewModelTest','ui.PreviewLifecycleTest','ui.LibraryCategoriesTest','ui.LibraryWorkspaceTest','sync.TeamOfflineHttpTest','sync.TeamOfflineRecoveryTest','sync.TeamOfflineRetireTest','ui.LibraryFolderScreenTest','domain.ScoreResolverTest')) {
        $taskArgs+=@('--tests',('com.ensemble.scorelibrary.'+$test))
    }
} else {
    $taskArgs+=@(':app:assembleRelease',':app:assembleDebug',':app:assembleDebugAndroidTest',':app:lintDebug',':app:lintRelease')
}
& 'C:\Users\dxt\Documents\Codex\developer-tools\gradle-8.14.3\bin\gradle.bat' @taskArgs
exit $LASTEXITCODE
